# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/m3uPlayer_softupdate.py
from os import popen, system, path, listdir, remove
import os
from Components.Label import Label
from Screens.Standby import TryQuitMainloop
from Screens.Screen import Screen
from Components.ScrollLabel import ScrollLabel
from Components.ActionMap import ActionMap, NumberActionMap
from enigma import getDesktop, eConsoleAppContainer
sz_w = getDesktop(0).size().width()
from Screens.MessageBox import MessageBox
gLogFile = None
from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import getversions2, gethostname, log as dlog
currversion, enigmaos, currpackage, currbuild = getversions2()

def m3uPlayerdataupdates():
    version = None
    link = None
    updates = None
    builddate = ''
    try:
        import urllib2
        fp = urllib2.urlopen('http://www.tunisia-dreambox.info/TSplugins/m3uPlayer/m3uPlayer_updates.txt')
        count = 0
        lines = fp.readlines()
        link16 = ''
        link20 = ''
        builddate = ''
        for line in lines:
            if line.startswith('software_version'):
                version = line.split('=')[1].strip()
            if line.startswith('software_fixupdate'):
                builddate = line.split('=')[1].strip()
            if line.startswith('software_link2.0'):
                link20 = line.split('=')[1].strip()
            if line.startswith('software_updates'):
                updates = line.split('=')[1].strip()
            link = link20
            if not enigmaos == 'oe2.0':
                link = link.replace('.ipk', '.deb')

        return ('none',
         version,
         link,
         updates,
         builddate)
    except:
        return ('error',
         version,
         link,
         updates,
         builddate)

    return


class m3uPlayerupdatesscreen(Screen):
    if sz_w == 1280:
        skin = '<screen name = "m3uPlayerupdatesscreen" position = "center,center" size = "790,570" backgroundColor = "#080000" flags = "wfNoBorder"> <ePixmap  position = "0,0"  size = "790,570"  pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/frame2.png"  alphatest = "blend"/> <ePixmap  position = "350,540"  size = "25,25"  pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"  zPosition = "3"  transparent = "1"  alphatest = "blend"/> <widget  name = "key_green"  position = "330,537"  zPosition = "4"  size = "200,24"  halign = "center"  font = "m3uPlayerFont;20"  transparent = "1"  foregroundColor = "#ffffff"  backgroundColor = "#41000000"/> <ePixmap  position = "330,530"  pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png"  size = "204,37"  zPosition = "2"  backgroundColor = "#ffffff"  alphatest = "blend"/> <widget  name = "info"  position = "20,50"  zPosition = "2"  size = "760,485"  font = "Regular;22"  foregroundColor = "#ffffff"  transparent = "1"  halign = "center"  valign = "center"/></screen>'
    else:
        skin = '<screen\n    name = "m3uPlayerupdatesscreen"\n    position = "center,center"\n    size = "1165,855"\n    backgroundColor = "#080000">\n    <ePixmap\n        position = "0,0"\n        size = "1185,855"\n        pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/frame2fhd.png"\n        alphatest = "blend"/>\n\n    <widget\n        name = "key_green"\n        position = "430,806"\n        zPosition = "4"\n        size = "390,36"\n        halign = "center"\n        font = "m3uPlayerFont;30"\n        transparent = "1"\n        foregroundColor = "#ffffff"\n        backgroundColor = "#41000000"/>\n    <ePixmap\n        position = "495,795"\n        pixmap = "/usr/lib/enigma2/python/Plugins//Extensions/m3uPlayer/skin/images/tab_active.png"\n        size = "306,56"\n        zPosition = "2"\n        backgroundColor = "#ffffff"\n        alphatest = "blend"/>\n    <ePixmap\n        position = "515,810"\n        size = "38,38"\n        pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"\n        zPosition = "3"\n        transparent = "1"\n        alphatest = "blend"/>        \n    <widget\n        name = "info"\n        position = "30,75"\n        zPosition = "2"\n        size = "1140,728"\n        font = "Regular;33"\n        foregroundColor = "#ffffff"\n        transparent = "1"\n        halign = "center"\n        valign = "center"/>\n</screen>\n'

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self['key_green'] = Label('Upgrade')
        self.updatestring = ''
        self.xmlversion = ''
        self.xmlupdates = ''
        self.xmlupdate = False
        self.update = False
        self.removefirst = False
        self.builddate = ''
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.close,
         'cancel': self.close,
         'blue': self.installLastupdate,
         'green': self.runsoftupdate}, -1)
        info = 'Checking software updates,please wait...'
        self['info'] = Label(info)
        self.onLayoutFinish.append(self.getupgradeinfo)

    def installLastupdate(self):
        if self.builddate.strip() == '':
            return
        else:
            self.builddate = self.builddate.replace('.zip', '')
            filename = '/tmp/' + self.builddate + '.zip'
            if True:
                url = 'http://www.tunisia-dreambox.info/TSplugins/m3uPlayer/' + self.builddate + '.zip'
                cmdlist = []
                cmdlist.append("wget -O '" + filename + "' -c '" + url + "'")
                cmdlist.append('unzip -o ' + filename + ' -d ' + '/')
                cmdlist.append('rm ' + filename)
                from Console3 import m3uPlayerConsole3
                self.session.open(m3uPlayerConsole3, title='Installing last update', cmdlist=cmdlist, finishedCallback=None, closeOnSuccess=False, instr=None, endstr=None)
            return

    def getupgradeinfo(self):
        debug = True
        try:
            new_addons = ''
            currversion, enigmaos, currpackage, currbuild = getversions2()
            error, version, link, updates, builddate = m3uPlayerdataupdates()
            self.builddate = builddate
            print 'error, version, link, updates', error, version, link, updates
            if error == 'error':
                self['info'].setText('Error in getting updates data,internet or server down,try later')
                return
            currbuild = builddate
            if error == 'error' or updates is None:
                self['info'].setText('Error getting data,check internet or server down')
                self['key_green'].setText(' ')
                self.update = False
                return
            if updates is None:
                self['info'].setText('Sorry unable to get updates info,no internet or server down!')
                self['key_green'].setText(' ')
                self.update = False
                return
            try:
                allupdates = updates.replace(':', '\n')
            except:
                self['info'].setText('Sorry unable to get updates info,no internet or server down!')
                self['key_green'].setText(' ')
                self.update = False
                return

            self.link = link
            print 'version,currversion', version, currversion
            if version.strip() == currversion.strip():
                self['info'].setText('m3uPlayer version: ' + currversion + '\nlast update:' + currbuild + ' Press blue to re-install last update\n\n No new version available\n\npress green button to remove and re-install current version,some addons may need reinstall\n')
                self.update = True
                self.removefirst = True
                self['key_green'].setText('re-install')
                return
            if float(version) > float(currversion):
                updatestr = 'm3uPlayer version: ' + currversion + '\n\nNew update ' + version + ' is available  \n updates:' + allupdates + '\n\npress green button to start updating\n'
                self['key_green'].setText('Upgrade')
                self.update = True
                self['info'].setText(updatestr)
            else:
                self['info'].setText('m3uPlayer version: ' + currversion + '\n\n No new version available\n')
        except:
            self.update = False
            self['info'].setText('unable to check for updates-No internet connection or server down-please check later')

        return

    def runsoftupdate(self):
        if self.update == False:
            return
        com = self.link
        dom = 'updates'
        target = '/tmp/updates.ipk'
        self.session.openWithCallback(self.close, m3uPlayerUpdateScreen, com)


class m3uPlayerUpdateScreen(Screen):
    skin_1280 = '    <screen\n        name = "m3uPlayerUpdateScreen"\n        position = "center,center"\n        size = "790,570"\n        title = "m3uPlayer Update"\n        backgroundColor = "#00060606"\n        flags = "wfNoBorder">\n        <ePixmap\n            position = "15,5"\n            size = "65,65"\n            zPosition = "0"\n            pixmap = "/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/updates.png"\n            alphatest = "on"/>\n        <widget\n            name = "tslog"\n            position = "15,70"\n            size = "730,500"\n            font = "m3uPlayerFont;22"\n            valign = "top"\n            halign = "left"\n            backgroundColor = "#00000000"\n            transparent = "1"\n            zPosition = "1"/>\n    </screen>'
    skin_1920 = '<screen name="m3uPlayerUpdateScreen" position="center,center" size="1185,855" title="m3uPlayer Update" backgroundColor="#00060606" flags="wfNoBorder"><ePixmap position="22,8" size="98,98" zPosition="0" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/interface/images/updates.png" alphatest="on" /><widget name="tslog" position="22,105" size="1095,750" font="m3uPlayerFont;33" valign="top" halign="left" backgroundColor="#00000000" transparent="1" zPosition="1" /></screen>'
    if sz_w == 1280:
        skin = skin_1280
    else:
        skin = skin_1920

    def __init__(self, session, updateurl):
        self.session = session
        self.updateurl = updateurl
        dlog('self.updateurl', str(self.updateurl))
        self['tslog'] = ScrollLabel()
        Screen.__init__(self, session)
        self.finsished = False
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions'], {'cancel': self.keyClose}, -2)
        self.onLayoutFinish.append(self.__onLayoutFinished)

    def __onLayoutFinished(self):
        sl = self['tslog']
        sl.instance.setZPosition(1)
        self['tslog'].setText('Starting update, please wait...')
        self.startPluginUpdate()

    def startPluginUpdate(self):
        try:
            downloadurl(str(self.updateurl))
        except:
            pass

        self.container = eConsoleAppContainer()
        if enigmaos == 'oe2.0':
            self.container.appClosed.append(self.finishedPluginUpdate)
            self.container.stdoutAvail.append(self.mplog)
            self.container.execute('opkg remove enigma2-plugin-extensions-m3uPlayer ; opkg update ; opkg install --force-overwrite --force-depends ' + '/tmp/tmp.pac')
        else:
            self.container.appClosed_conn = self.container.appClosed.connect(self.finishedPluginUpdate)
            self.container.stdoutAvail_conn = self.container.stdoutAvail.connect(self.mplog)
            self.container.execute('dpkg -r enigma2-plugin-extensions-m3uPlayer ;  dpkg -i --force-depends --force-overwrite /tmp/tmp.pac; apt-get -f -y install')

    def finishedPluginUpdate(self, retval):
        self.finished = True
        try:
            self.container.kill()
        except:
            pass

        if retval == 0:
            self.session.openWithCallback(self.restartGUI, MessageBox, _('m3uPlayer successfully updated!\nDo you want to restart the Enigma2 GUI now?'), MessageBox.TYPE_YESNO)
        elif retval == 2:
            self.session.openWithCallback(self.returnGUI, MessageBox, _('m3uPlayer update failed! Please check free space on your root filesystem, at least 6MB are required for installation.\nCheck the update log at tmp/TSmeida!\ntry to install from tools/files/official software'), MessageBox.TYPE_ERROR)
        else:
            self.session.openWithCallback(self.returnGUI, MessageBox, _('m3uPlayer update failed! Check tmp/m3uPlayer/m3uPlayer_update_log !'), MessageBox.TYPE_ERROR)

    def restartGUI(self, answer):
        self.finished = True
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def keyClose(self):
        self.close()

    def restartGUI2(self, answer):
        self.session.open(TryQuitMainloop, 3)

    def returnGUI(self, answer):
        pass

    def mplog(self, str):
        print 'st', str
        self['tslog'].setText(str)
        self.writeToLog(str)

    def writeToLog(self, log):
        global gLogFile
        if gLogFile is None:
            self.openLogFile()
        gLogFile.write(str(log) + '\n')
        gLogFile.flush()
        return

    def openLogFile(self):
        global gLogFile
        baseDir = '/tmp'
        logDir = baseDir + '/m3uPlayer'
        import datetime
        try:
            now = datetime.datetime.now()
        except:
            pass

        try:
            os.makedirs(baseDir)
        except OSError as e:
            pass

        try:
            os.makedirs(logDir)
        except OSError as e:
            pass

        try:
            gLogFile = open(logDir + '/m3uPlayer_update_%04d%02d%02d_%02d%02d.log' % (now.year,
             now.month,
             now.day,
             now.hour,
             now.minute), 'w')
        except:
            gLogFile = open(logDir + '/m3uPlayer_update', 'w')


def downloadurl(url):
    localf = '/tmp/tmp.pac'
    import urllib
    a, b = urllib.urlretrieve(url, localf)
