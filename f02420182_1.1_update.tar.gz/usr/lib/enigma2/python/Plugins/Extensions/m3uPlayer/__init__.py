# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/BrothersTV/__init__.py
pass