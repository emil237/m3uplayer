# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/plugin.py
from skin import loadSkin
import os
from Components.config import config, ConfigIP, ConfigInteger, ConfigDirectory, ConfigSubsection, ConfigSubList, ConfigEnableDisable, ConfigNumber, ConfigText, ConfigSelection, ConfigYesNo, ConfigPassword, getConfigListEntry, configfile
from Components.ConfigList import ConfigListScreen
from Tools.Directories import resolveFilename, pathExists, SCOPE_MEDIA, copyfile, fileExists, createDir, removeDir, SCOPE_PLUGINS, SCOPE_CURRENT_SKIN
config.m3uPlayer = ConfigSubsection()
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.MenuList import MenuList
from enigma import eTimer, eListboxPythonMultiContent, getDesktop, gFont, loadPNG, addFont
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from twisted.web.client import downloadPage, getPage, error
from Components.ActionMap import ActionMap, NumberActionMap
config.m3uPlayer.searchstr= ConfigText(default='bein', fixed_size=False)
config.m3uPlayer.softaware_update = ConfigEnableDisable(default=False)
config.m3uPlayer.showthumbnail = ConfigEnableDisable(default=True)
config.m3uPlayer.nonstopplay = ConfigEnableDisable(default=False)
config.m3uPlayer.menuplugin = ConfigEnableDisable(default=True)
config.m3uPlayer.fanart = ConfigEnableDisable(default=True)
config.m3uPlayer.favlocation = ConfigText(default='/etc/m3uPlayer', fixed_size=False)
config.m3uPlayer.times = ConfigInteger(default=0, limits=(5, 99))
config.m3uPlayer.host = ConfigText(default='http://www.pro213.tv', fixed_size=False)
config.m3uPlayer.framesize = ConfigInteger(default=30, limits=(5, 99))
config.m3uPlayer.slidetime = ConfigInteger(default=10, limits=(1, 60))
config.m3uPlayer.resize = ConfigSelection(default='1', choices=[('0', _('simple')), ('1', _('better'))])
config.m3uPlayer.cache = ConfigEnableDisable(default=True)
config.m3uPlayer.loop = ConfigEnableDisable(default=True)
config.m3uPlayer.downloadlocation = ConfigText(default='/media/hdd', fixed_size=False)
config.m3uPlayer.bgcolor = ConfigSelection(default='#080000', choices=[('#080000', _('black')),
 ('#009eb9ff', _('blue')),
 ('#00ff5a51', _('red')),
 ('#00ffe875', _('yellow')),
 ('#0038FF48', _('green'))])
config.m3uPlayer.textcolor = ConfigSelection(default='#00ffe875', choices=[('#76addc', _('CornflowerBlue')),
 ('#009eb9ff', _('blue')),
 ('#00ff5a51', _('red')),
 ('#00ffe875', _('yellow')),
 ('#0038FF48', _('green'))])
config.m3uPlayer.label_textsize = ConfigSelection(default='20', choices=[('20', _('20')),
 ('22', _('22')),
 ('24', _('24')),
 ('18', _('18')),
 ('16', _('16'))])
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer'
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer'

downloadlocation = config.m3uPlayer.downloadlocation.value
dwidth = getDesktop(0).size().width()


from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import getversions2, gethostname, log
currversion, enigmaos, currpackage, currbuild = getversions2()

def mkdir(path):
    try:
        if os.path.exists(path) == False:
            os.makedirs(path)
    except:
        pass




class m3uPlayerbootlogo(Screen):
    skin = '<screen name="m3uPlayerbootlogo" position="center,center" size="990,720" title="" flags="wfNoBorder"><eLabel  position = "345,415"   zPosition = "4"   size = "100,25"  halign = "center"  font = "m3uPlayerFont;22"  transparent = "1" foregroundColor = "#ffffff" backgroundColor = "#41000000" text = "Loading.."/><ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/framesd.png" position="0,0" size="990,720" /></screen>'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.active = False
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.disappear,
         'cancel': self.disappear}, -1)
        self.update_available = False
        self.plugin_name = 'm3uPlayer'
        self.systemlock = ''
        self.timer1 = eTimer
        self.timer2 = eTimer
        self.version = currversion
        self.currversion = currversion
        self.updateinfo = self.currversion + '_False_' + self.version
       
        if enigmaos == 'oe2.0':
            try:
                self.timer1.callback.append(self.checkupdates)
                self.timer1.start(100, False)
            except:
                self.onLayoutFinish.append(self.checkupdates)

        else:
            try:
                self.timer1_conn = self.timer1.timeout.connect(self.checkupdates)
                self.timer1.start(100, False)
            except:
                self.onLayoutFinish.append(self.checkupdates)

    def back_close(self, result = None):
        if result:
            try:
                self.timer1.stop()
            except:
                pass

            try:
                if enigmaos == 'oe2.0':
                    self.timer1.callback.remove(self.disappear)
                else:
                    self.timer1_conn = None
            except:
                pass

            self.close()
        return

    def checkupdates(self):
        try:
            self.timer1.stop()
        except:
            pass

        
        url = 'http://tunisia-dreambox.info/TSplugins/m3uPlayer/m3uPlayer_updates.txt'
        getPage(url, headers={'Content-Type': 'application/x-www-form-urlencoded'},timeout=20).addCallback(self.parseData).addErrback(self.addErrback)
        self.timer2 = eTimer()
        if enigmaos == 'oe2.0':
            self.timer2.callback.append(self.disappear)
        else:
            self.timer2_conn = self.timer2.timeout.connect(self.disappear)
        self.timer2.start(2000, False)

    def addErrback(self, result):
        if result:
            print result
        self.disappear()

    def parseData(self, data):
        debug = True
        try:
            updated_addons = ''
            new_addons = []
            version = '1.0'
            self.update_available = False
            currversion, enigmaos, currpackage, currbuild = getversions2()
            self.version = currversion
            self.currversion = currversion
            autoinstall = 'yes'
            try:
                for line in data.splitlines():
                    line = line.strip()
                    if line.startswith('name'):
                        self.plugin_name = line.split('=')[1].strip()
                    if line.startswith('software_version'):
                        version = line.split('=')[1].strip()
                        self.version = version
                    if line.startswith('software_fixupdate') and '=' in line:
                        new_update_file = line.split('=')[1]
                        print 'new_update_file', new_update_file
                        newupdate = True
                        try:
                            if new_update_file.strip() == '':
                                newupdate = False
                        except:
                            newupdate = False

                        debug = True
                        if newupdate == True:
                            try:
                                if new_update_file.endswith('.zip'):
                                    new_update_file = new_update_file[:-4]
                                uptype, upversion, update = new_update_file.split('_')
                                if float(upversion) == float(currversion):
                                    if not os.path.exists(PLUGIN_PATH + '/updates/' + new_update_file):
                                        afile = open(PLUGIN_PATH + '/updates/' + new_update_file, 'w')
                                        afile.close()
                                        url = 'http://www.tunisia-dreambox.info/TSplugins/m3uPlayer/' + new_update_file + '.zip'
                                        print 'url', url
                                        target = '/tmp/' + new_update_file + '.zip'
                                        if os.path.exists(target):
                                            os.remove(target)
                                        from lib.amdownload import startdownload
                                        startdownload(self.session, 'download', url, target, new_update_file, None, False)
                            except:
                                pass

            except:
                pass

            if float(self.version) > float(self.currversion):
                self.updateinfo = str(self.currversion) + '_' + 'True' + '_' + str(self.version)
            else:
                self.updateinfo = str(self.currversion) + '_' + 'False' + '_' + str(self.version)
            self.disappear()
        except:
            self.disappear()

        return

    def disappear(self):
        try:
            self.timer2.stop()
            self.timer1.stop()
            if enigmaos == 'oe2.0':
                self.timer2.callback.remove(self.disappear)
            else:
                self.timer2_conn = None
        except:
            pass

        if True:
            from startmenu import m3uPlayerStartMenuscrn
            self.session.openWithCallback(self.close, m3uPlayerStartMenuscrn, self.updateinfo, self.plugin_name, self.back_close, self.active)
        return


def main(session, **kwargs):
    import os
    skinPath = plugin_path + '/skin/skin_default.xml'
    skinPathfhd = plugin_path + '/skin/skin_defaultfhd.xml'
    if dwidth == 1920:
        if os.path.exists(skinPathfhd):
            loadSkin(skinPathfhd)
            print 'skin loaded' + skinPathfhd
        else:
            print 'failed to load m3uPlayer skin ' + skinPathfhd
    elif os.path.exists(skinPath):
        loadSkin(skinPath)
        print 'skin loaded' + skinPath
    else:
        print 'failed to load m3uPlayer skin ' + skinPath
    fontpath = PLUGIN_PATH + '/skin'
    debug = True
    try:
        fontpath = PLUGIN_PATH + '/skin'
        addFont('%s/font_default.otf' % fontpath, 'm3uPlayerFont', 100, 1)
    except:
        print 'font not added'


    
    if os.path.exists('/tmp/m3uPlayer/') == False:
        mkdir('/tmp/m3uPlayer/')
    if os.path.exists('/etc/m3uPlayer/') == False:
        mkdir('/etc/m3uPlayer/')
    if os.path.exists('/tmp/m3uPlayer/json') == False:
        mkdir('/tmp/m3uPlayer/json')
    if os.path.exists('/etc/m3uPlayer/') == False:
        mkdir('/etc/m3uPlayer/')
    if os.path.exists(PLUGIN_PATH + '/lib/defaults/favorites2.xml') and os.path.exists('/etc/m3uPlayer/favorites2.xml') == False:
        from Tools.Directories import copyfile
        copyfile(PLUGIN_PATH + '/lib/defaults/favorites2.xml', '/etc/m3uPlayer/favorites2.xml')
    try:
        value=int(config.m3uPlayer.times)
        config.m3uPlayer.times.value=value+1
        config.m3uPlayer.times.save()
    except:
        value=10
    
    session.open(m3uPlayerbootlogo)


def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [(_('m3uPlayer'),
          main,
          'm3uPlayer_mainmenu',
          2)]
    return []


def Plugins(**kwargs):
    list = []
    try:
        if config.m3uPlayer.menuplugin.value == True:
            list.append(PluginDescriptor(icon='plugin.png', name='m3uPlayer', description='m3uPlayer', where=PluginDescriptor.WHERE_MENU, fnc=menu))
    except:
        list.append(PluginDescriptor(icon='plugin.png', name='m3uPlayer', description='em3uPlayer', where=PluginDescriptor.WHERE_MENU, fnc=menu))

    list.append(PluginDescriptor(icon='plugin.png', name='m3uPlayer', description='m3uPlayer', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    return list
