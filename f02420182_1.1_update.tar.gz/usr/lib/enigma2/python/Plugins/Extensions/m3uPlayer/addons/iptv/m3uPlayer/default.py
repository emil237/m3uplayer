# 2014.10.25 01:13:58 Jordan Daylight Time
#Embedded file name: /media/hdd/Extensions/TSmedia/addons/iptv/plugin.video.userm3uplayer/default.py

import sys
import urllib, urllib2, re, os
module_path = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/addons/iptv/m3uPlayer'
path = '/tmp/m3uPlayer'

from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import getversions2, gethostname, log as dlog
currversion, enigmaos, currpackage, currbuild = getversions2()
from Components.config import config
#host=config.m3uPlayer.host.value
from httplib import HTTP
from urlparse import urlparse
import StringIO
import httplib



def getuserlist():
    folder = '/etc/m3uPlayer/'
    files = []
    fullpath = []
    user_iptv_file = '/etc/m3uPlayer/iptvlist'
    if os.path.exists(user_iptv_file):
        f = open(user_iptv_file, 'r')
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line.startswith('m3u'):
                parts = line.split(';')
                itemtype = parts[0]
                itempath = parts[2]
                itemname = parts[1]
                try:
                    if not os.path.exists(folder + itemname + '.m3u'):
                       urllib.urlretrieve(itempath, folder + itemname + '.m3u')
                    if not os.path.exists(folder + itemname + '.lnk'):
                       cfile=open(folder + itemname + '.lnk',"w")
                       cfile.write(itempath)
                       cfile.close()
                       
                except:
                    pass

    if os.path.exists(folder):
        emptyfolder = True
        for item in os.listdir(folder):
            itempath = folder + item
            if os.path.isfile(itempath):
                if item.endswith('.m3u'):
                    itemname = item.replace('.m3u', '')
                    icon=geticon(itemname)
                    addDir(itemname, itempath, 1, icon,'',1)
                    
                    emptyfolder = False

        if emptyfolder == True:
            addDir('No m3u file in etc/m3uPlayer', 1, '', '',1)





def geticon(title):
               icon=''

               if 'sport' in title.lower():
                  icon=module_path+"/img/sport.png"               

               if 'kids' in title.lower():
                  icon=module_path+"/img/kids.png"
               
               if 'movies' in title.lower():
                  icon=module_path+"/img/movies.png"
               
               if 'france' in title.lower() or 'fr:' in title.lower():
                  icon=module_path+"/img/france.png"
               if 'arab' in title.lower() or 'ar' in title.lower():
                  icon=module_path+"/img/arab.png"
               
               if 'portugal' in title.lower():
                  icon=module_path+"/img/portugal.png"
               if 'sky' in title.lower():
                  icon=module_path+"/img/sky.png"
               
               if 'nilesat' in title.lower() :
                  icon=module_path+"/img/nilesat.png"
               if 'usa' in title.lower() :
                  icon=module_path+"/img/uk.png"
               if 'tunisia' in title.lower():
                  icon=module_path+"/img/tunisia.png"                 
                  
               if 'bein' in title.lower():
                  icon=module_path+"/img/bein.png"
               if 'osn' in title.lower():
                  icon=module_path+"/img/osn.png"
               if icon=='':
                   icon=module_path+"/icon.png"
               return icon



##################
def _getM3uIcon( item,group_title):
        title=group_title
        icon = item.get('tvg-logo', '')
        if icon=='':
           item.get('logo', '') 
        if icon=='':
           icon = item.get('art', '')
           
        if icon=='':
               if 'sport' in title.lower():
                  icon=module_path+"/img/sport.png"               

               if 'kids' in title.lower():
                  icon=module_path+"/img/kids.png"
               
               if 'movies' in title.lower():
                  icon=module_path+"/img/movies.png"
               
               if 'france' in title.lower() or 'fr:' in title.lower():
                  icon=module_path+"/img/france.png"
               if 'arab' in title.lower() or 'ar' in title.lower():
                  icon=module_path+"/img/arab.png"
               
               if 'portugal' in title.lower():
                  icon=module_path+"/img/portugal.png"
               if 'sky' in title.lower():
                  icon=module_path+"/img/sky.png"
               
               if 'nilesat' in title.lower() :
                  icon=module_path+"/img/nilesat.png"
               if 'usa' in title.lower() :
                  icon=module_path+"/img/uk.png"
               if 'tunisia' in title.lower() :
                  icon=module_path+"/img/tunisia.png"                 
                  
               if 'bein' in title.lower():
                  icon=module_path+"/img/bein.png"
               if 'osn' in title.lower():
                  icon=module_path+"/img/osn.png"

               if icon=='':
                   icon=module_path+"/icon.png"
                  
        return icon
        
 
def listM3u( m3ufile):
           
        baseUrl = ''
        data = ''
        data=open(m3ufile).read()        
        
        
        from m3uparser import  ParseM3u
        data = ParseM3u(data)

       
        groups = []
        groups_list=[]
        links=[]
        for item in data:

            group_title = item.get('group-title', '')
            url = item['uri']
            icon = _getM3uIcon(item,group_title)
            
            if item['f_type'] == 'inf':
                
                
                if group_title !="":    
                    if group_title not in groups_list:
                            groupIcon = item.get('group-logo', '')
                            if groupIcon =='':
                               groupIcon = item.get('group-art', '')
                            if  groupIcon =='':
                                groupIcon = icon
                            
                            groups_list.append(group_title)
                            groups.append((group_title,m3ufile,groupIcon))
                            

                else:
                    title = item.get('title', '')
                    url = item['uri']
                    icon = _getM3uIcon(item,title)
                    
                    links.append((title,url,icon))                      
                    
                    
                        
        if len(groups)!=0:
             print "groups",groups
             for group in groups:
                
                 addDir(group[0],group[1],2,group[2])
             return groups
        else:
            for link in links:
                addDir(link[0], link[1], 0, link[2])
                
            
def listM3unogroups( m3ufile):
           
        baseUrl = ''
        data = ''
        data=open(m3ufile).read()        
        
        
        from m3uparser import  ParseM3u
        data = ParseM3u(data)

       
        groups = []
        groups_list=[]
        links=[]
        for item in data:

            group_title = item.get('group-title', '')
            url = item['uri']
            icon = _getM3uIcon(item,group_title)
            
            if item['f_type'] == 'inf':
                
                
                
                    title = item.get('title', '')
                    url = item['uri']
                    icon = _getM3uIcon(item,title)
                    
                    links.append((title,url,icon))                      
                    
                    
                        
        print "links",links
        if links:
            for link in links:
                addDir(link[0], link[1], 0, link[2])
def listM3usearch( m3ufile):
           
        baseUrl = ''
        data = ''
        data=open(m3ufile).read()        
        
        
        from m3uparser import  ParseM3u
        data = ParseM3u(data)

        
        search_str=config.m3uPlayer.searchstr.value
        groups = []
        groups_list=[]
        links=[]
        for item in data:

            group_title = item.get('group-title', '')
            url = item['uri']
            icon = _getM3uIcon(item,group_title)
            
            if item['f_type'] == 'inf':
                
                
                
                    title = item.get('title', '')
                    if search_str.lower() in title.lower():
                        url = item['uri']
                        icon = _getM3uIcon(item,title)
                        
                        links.append((title,url,icon))                      
                    
                    
                        
        print "links",links
        if links:
            for link in links:
                addDir(link[0], link[1], 0, link[2])                
                
def listM3ubygroup(selgroup,m3ufile):
           
        baseUrl = ''
        data = ''
        data=open(m3ufile).read()        
        
        
        from m3uparser import  ParseM3u
        data = ParseM3u(data)

       
        groups = []
        links=[]
        for item in data:

            group = item.get('group-title', '')
            url = item['uri']
            icon = _getM3uIcon(item,group)
            
            if item['f_type'] == 'inf':
                
                
                if group !="":    
                    if group ==selgroup:
                        title = item.get('title', '')
                        url = item['uri']
                        icon = _getM3uIcon(item,title)
                        links.append((title,url,icon))                      
                    

        if links:
            for link in links:
                addDir(link[0], link[1], 0, link[2])                

                    
                  


def addDir(name, url, mode, iconimage, desc = '', page = ''):
    global list2
    if not page == '':
        u = module_path + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&page=' + str(page)
    else:
        u = module_path + '?url=' + urllib.quote_plus(url) + '&mode=' + str(mode) + '&name=' + urllib.quote_plus(name) + '&desc=' + urllib.quote_plus(desc) + '&page='
    if mode == 0:
        list2.append((name,
         url,
         iconimage,
         '',
         '',
         page))
    else:
        list2.append((name,
         u,
         iconimage,
         '',
         '',
         page))


def trace_error():
    import traceback
    try:
        traceback.print_exc(file=open('/tmp/m3uPlayer/m3uPlayer_log', 'a'))
    except:
        pass





def get_params(action_param):
    param = []
    paramstring = action_param
    if paramstring is None or paramstring == '':
        paramstring = ''
    else:
        paramstring = '?' + action_param.split('?')[1]
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if len(splitparams) == 2:
                param[splitparams[0]] = splitparams[1]

    print 'input,output', paramstring, param
    return param


def process_mode(list1 = [], action_param = None):
    global list2
    try:
       
       
        list2 = []
        params = get_params(action_param)
        url = None
        name = None
        mode = None
        page = ''
        try:
            url = urllib.unquote_plus(params['url'])
        except:
            pass

        try:
            name = urllib.unquote_plus(params['name'])
        except:
            pass

        try:
            mode = int(params['mode'])
        except:
            pass

        try:
            page = str(params['pageToken'])
        except:
            page = 1

        print 'Mode: ' + str(mode)
        print 'URL: ' + str(url)
        print 'Name: ' + str(name)
        print 'page: ' + str(page)
        if type(url) == type(str()):
            url = urllib.unquote_plus(url)
        if mode == None:
            
            
            name = 'Bouquets'
            page = 1
          
            getuserlist()
        elif mode == 1:
            print '' + url
            try:
                cfile=open("/tmp/m3uPlayer/m3ufile","w")
                cfile.write(name)
                cfile.close()
            except:
                pass
            listM3u(url)
        elif mode == 2:
            listM3ubygroup(name,url)


        elif mode == 4:
            print '' + url
            try:
                cfile=open("/tmp/m3uPlayer/m3ufile","w")
                cfile.write(name)
                cfile.close()
            except:
                pass
            listM3unogroups(url)
        elif mode == 103:
            print '' + url
            
            listM3usearch(url)            
    except:
        addDir('Error:script error [error 1050]', '', '', '', desc='', page='')
        trace_error()
   
    return list2
