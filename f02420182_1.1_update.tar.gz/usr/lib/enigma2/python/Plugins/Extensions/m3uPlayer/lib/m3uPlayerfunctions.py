# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/m3uPlayerfunctions.py
import os, urllib
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer'

def getversions2():
    currversion = 'oe2.0'
    enigmaos = 'oe2.0'
    currpackage = 'full'
    currbuild = '01012016'
    if os.path.exists(PLUGIN_PATH + '/version'):
        try:
            fp = open(PLUGIN_PATH + '/version', 'r').readlines()
            for line in fp:
                if 'version' in line:
                    currversion = line.split(':')[1].strip()
                if 'kernel' in line:
                    enigmaos = line.split(':')[1].strip()
                if 'package' in line:
                    currpackage = line.split(':')[1].strip()
                if 'build' in line:
                    currbuild = line.split(':')[1].strip()

        except:
            pass

    return (currversion,
     enigmaos,
     currpackage,
     currbuild)


def gethostname():
    path = '/etc/hostname'
    hostname = 'None'
    if os.path.exists(path):
        f = open(path, 'r')
        hostname = f.read()
        f.close()
        if 'dm800se' in hostname:
            return 'dm800se'
        if 'dm8000' in hostname:
            return 'dm8000'
        if 'dm800' in hostname:
            return 'dm800hd'
        if 'dm500' in hostname:
            return 'dm500hd'
        if 'dm7020' in hostname:
            return 'dm7020hd'
        if 'dm820' in hostname:
            return 'dm820'
        if 'dm520' in hostname:
            return 'dm520'
        if 'dm7080' in hostname:
            return 'dm7080'
        if 'dm900' in hostname:
            return 'dm900'
        return 'None'
    return 'None'


def log(label, txt):
    txt = str(txt)
    label = str(label)
    try:
        afile = open('/tmp/m3uPlayer/m3uPlayer_log', 'a')
    except:
        return

    afile.write('\n' + label + ':' + txt)
    afile.close()


def addstreamboq(bouquetname = None):
    boqfile = '/etc/enigma2/bouquets.tv'
    if not os.path.exists(boqfile):
        pass
    else:
        fp = open(boqfile, 'r')
        lines = fp.readlines()
        fp.close()
        add = True
        for line in lines:
            if 'userbouquet.' + bouquetname + '.tv' in line:
                add = False
                break

    if add == True:
        fp = open(boqfile, 'a')
        fp.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.%s.tv" ORDER BY bouquet\n' % bouquetname)
        fp.close()
        add = True


def addstream(url = None, name = None, bouquetname = None):
    error = 'none'
    if bouquetname == None:
        
       bouquetname = 'm3u2Player'
       
    fileName = '/etc/enigma2/userbouquet.%s.tv' % bouquetname
    out = '#SERVICE 4097:0:0:0:0:0:0:0:0:0:%s:%s\r\n' % (urllib.quote(url), urllib.quote(name))
    try:
        addstreamboq(bouquetname)
        if not os.path.exists(fileName):
            fp = open(fileName, 'w')
            fp.write('#NAME %s\n' % bouquetname)
            fp.close()
            fp = open(fileName, 'a')
            fp.write(out)
        else:
            fp = open(fileName, 'r')
            lines = fp.readlines()
            fp.close()
            for line in lines:
                if out in line:
                    error = 'Stream already added to bouquet'
                    return error

            fp = open(fileName, 'a')
            fp.write(out)
        fp.write('')
        fp.close()
    except:
        error = 'Adding to bouquet failed'

    return error
