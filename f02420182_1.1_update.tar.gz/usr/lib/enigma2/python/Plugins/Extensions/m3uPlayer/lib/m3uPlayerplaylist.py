# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/m3uPlayerplaylist.py
from imports import *
import os
THISPLUG = PLUGIN_PATH
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from enigma import getPrevAsciiCode, gPixmapPtr, eConsoleAppContainer, eSize, RT_WRAP, ePoint, eTimer, addFont, loadPNG, quitMainloop, eListbox, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont, getDesktop, ePicLoad, eServiceCenter, iServiceInformation, eServiceReference, iSeekableService, iPlayableService, iPlayableServicePtr, eDVBDB
sz_w = getDesktop(0).size().width()
from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import log

def streamMenuList_playlist(streamMenuList):
    if sz_w == 1280:
        streamMenuList.l.setFont(0, gFont('m3uPlayerFont', 24))
        streamMenuList.l.setItemHeight(40)
    else:
        streamMenuList.l.setFont(0, gFont('m3uPlayerFont', 30))
        streamMenuList.l.setItemHeight(60)


class m3uPlayerplaylist(Screen):
    if sz_w == 1280:
        skin = '''<screen name="m3uPlayerplaylist" position="20,20" size="535,700" backgroundColor="#54111112" title=" " transparent="0">

<widget name="streamlist" position="3,20" size="228,600" itemHeight="60" backgroundColor="#54111112" foregroundColor="#9dc014" foregroundColorSelected="#ffffff" backgroundColorSelected="#41000000"  transparent="1" />
<widget name="streamlist2" position="235,20" itemHeight="60" size="300,600" backgroundColor="#54111112" foregroundColor="#fae878" foregroundColorSelected="#ffffff" backgroundColorSelected="red" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/sel.png" transparent="1" />
<eLabel text = "+Favorites"  font = "m3uPlayerFont;20"  position = "240,625" size = "150,25"  halign = "center" foregroundColor = "black" backgroundColor = "yellow"  transparent = "0"/>
<widget name="programm" position="20,660" zPosition="4" size="480,60" font="m3uPlayerFont;20" foregroundColor="#ffffff" transparent="1" halign="left" valign="top" />
</screen> '''
    else:
        skin = '''<screen name="m3uPlayerplaylist" position="30,30" size="800,1040" backgroundColor="#54111112" title=" " transparent="0">

<widget name="streamlist" position="7,30" size="342,900" itemHeight="90" backgroundColor="#54111112" foregroundColor="#9dc014" foregroundColorSelected="#ffffff" backgroundColorSelected="#41000000"  transparent="1" />
<widget name="streamlist2" position="350,30"  itemHeight="60" size="450,900" backgroundColor="#54111112" foregroundColor="#fae878" foregroundColorSelected="#ffffff" backgroundColorSelected="red" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/sel.png" transparent="1" />
<eLabel text = "+Favorites"  font = "m3uPlayerFont;33"  position = "360,930" size = "220,40"  halign = "center" foregroundColor = "black" backgroundColor = "yellow"  transparent = "0"/>
<widget name="programm" position="20,970" zPosition="4" size="800,100" font="m3uPlayerFont;30" foregroundColor="#ffffff" transparent="1" halign="left" valign="top" />
</screen>

'''
    def __init__(self, session, playlist = [], playindex = 0, sendback = None, bqindex = 0, favmode = False):
        Screen.__init__(self, session)
        self.session = session
        self.playindex = playindex
        self.sendback = sendback
        self.bqindex = bqindex + 1
        self.playlist = playlist
        print self.playlist
        self.favmode = favmode
        self.select_set = False
        self.lucent = 1
        
        self['programm']=Label('loading... ')
        self['actions'] = ActionMap(['ColorActions','OkCancelActions', 'WizardActions'], {'ok': self.keyOK,
         'left': self.keyLeft,
         'right': self.keyRight,
         'yellow': self.addfav,                                                                  
         'up': self.keyUp,
         'down': self.keyDown,
         'cancel': self.keyCancel}, -1)
        self.searchtube = False
        self.streamMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.streamMenuList2 = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        streamMenuList_playlist(self.streamMenuList2)
        self.timer = eTimer()
        self['streamlist'] = self.streamMenuList
        self['streamlist2'] = self.streamMenuList2
        self.keyLocked = True
        self.page = 1
        self.currentlist = 'streamlist'
        self.timer2 = eTimer()
        try:
            self.timer.callback.append(self.layoutfinished)
        except:
            self.timer_conn = self.timer.timeout.connect(self.layoutfinished)

        self.timer.start(20, 1)

    def ListToMulticontent(self):
        cacolor = 16776960
        cbcolor = 16753920
        cccolor = 15657130
        cdcolor = 16711680
        cecolor = 16729344
        cfcolor = 65407
        cgcolor = 11403055
        chcolor = 13047173
        cicolor = 13789470
        scolor = cbcolor
        res = []
        theevents = []
        self.events = []
        self.events = self.streamList
        if sz_w == 1280:
            self['streamlist'].l.setItemHeight(60)
            self['streamlist'].l.setFont(0, gFont('m3uPlayerFont', 24))
        else:
            self['streamlist'].l.setItemHeight(90)
            self['streamlist'].l.setFont(0, gFont('m3uPlayerFont', 30))
        
        for i in range(0, len(self.events)):
            txt = self.events[i][0]
            png = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/channels/small_'+str(txt).lower().replace(" ","_")+'.png'
            print "pngxxx",png
            if os.path.exists(png)==False:
                png='/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/channels/small_iconch.png'
            
            if self.favmode == True and i == 0:
                self.select_set = True
                scolor = cacolor
            elif i == self.bqindex and self.select_set == False:
                scolor = cacolor
            else:
                scolor = cbcolor
            res.append(MultiContentEntryText(pos=(0, 1), size=(0, 0), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, text="", color=scolor, color_sel=cccolor, border_width=3, border_color=806544))    
            res.append(MultiContentEntryPixmapAlphaTest(pos=(1, 1), size=(45, 60), png=loadPNG(png)))
            if sz_w == 1280:
                res.append(MultiContentEntryText(pos=(47, 1), size=(180, 60), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, text=str(txt), color=scolor, color_sel=cccolor, border_width=3, border_color=806544))
            else:
                res.append(MultiContentEntryText(pos=(67, 1), size=(320, 90), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, text=str(txt), color=scolor, color_sel=cccolor, border_width=3, border_color=806544))
            theevents.append(res)
            res = []

        self['streamlist'].l.setList(theevents)
        self['streamlist'].show()

    def TSmediaMenu1_channels(self, entry):
        if sz_w == 1280:
            png = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/spicons/tv.png'
            try:
                return [entry, (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
                  0,
                  5,
                  31,
                  31,
                  loadPNG(png)), (eListboxPythonMultiContent.TYPE_TEXT,
                  40,
                  5,
                  490,
                  31,
                  0,
                  RT_HALIGN_LEFT,
                  str(entry[0]))]
            except:
                pass

        else:
            png = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/spicons/tv.png'
            try:
                return [entry, (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST,
                  0,
                  7,
                  46,
                  46,
                  loadPNG(png)), (eListboxPythonMultiContent.TYPE_TEXT,
                  60,
                  7,
                  750,
                  46,
                  0,
                  RT_HALIGN_LEFT,
                  str(entry[0]))]
            except:
                pass

    def layoutfinished(self):
        self.streamList = []
        self.timer.stop()
        from Plugins.Extensions.m3uPlayer.addons.iptv.m3uPlayer.default import process_mode
        try:
            self.source_data = process_mode([], None)
        except:
            return

        self.streamList.append(('Favorites', 'Favorites', 'Favorites'))
        try:m3ufile=open("/tmp/m3uPlayer/m3ufile").read()
        except:m3ufile=None
                 
        for item in self.source_data:
            if item[0]==m3ufile:
               self.streamList.append((item[0], item[1], item[2]))

        self.streamList2 = self.playlist
        self.ListToMulticontent()
        self.streamMenuList2.setList(map(self.TSmediaMenu1_channels, self.streamList2))
        self['streamlist'].selectionEnabled(0)
        self['streamlist2'].selectionEnabled(1)
        self.currentlist = 'streamlist2'
        
        self['programm'].setText(' ')
        log('self.favmodetpl,aylist', str(self.favmode))
        try:bouquet=open("/tmp/m3uPlayer/m3ufile").read()
        except:bouquet=None
          
        if self.favmode:
            try:
                self.streamMenuList.moveToIndex(0)
                self.streamMenuList2.moveToIndex(self.playindex)
            except:
                pass

        else:
            try:
                self.streamMenuList.moveToIndex(1)
                self.streamMenuList2.moveToIndex(self.playindex)
            except:
                pass

        return
    def favexists(self,title=None,param=None):
        if title is None or param is None:
            return False       
        try:

            from xml.etree.ElementTree import ElementTree, dump, SubElement, Element        
            favlocation = "/etc/m3uPlayer"
            xmlfile = favlocation + '/favorites2.xml'            
            tree = ElementTree()
            tree.parse(xmlfile)
            root = tree.getroot()
            i = 0
            for addon in root.iter('addon'):
                    for media in addon.iter('media'):
                        favtitle = str(media.attrib.get('title'))
                        favurl = str(media.text)
                        if title==favtitle and param==favurl:
                            return True
            return False             
        except:
            return False

    def addfav(self):
        
        from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import addfavorite
        result = False
        try:
            if self.currentlist == 'streamlist2':
                title = self[self.currentlist].getCurrent()[0][0]
                param = self[self.currentlist].getCurrent()[0][1]
            else:
                self['programm'].setText('No selected channel')
                return
        except:
            return
        try:
            
            
            
            
            if self.favexists(title,param):
               self['programm'].setText('Channel already added to favorites.')
               
               return
               
            result = addfavorite('iptv/m3uPlayer', str(title), str(param), 'iptv')
        except:
            result = False

        if result == True:
            self['programm'].setText(title + ' added  to favorites.')
        else:
            self['programm'].setText('Failed to add to favorites.')
        

    def keyUp(self):
        self['programm'].setText(' ')
        
        self[self.currentlist].up()
        itemindex = self[self.currentlist].getSelectionIndex()
        if self.currentlist == 'streamlist':
            self.streamMenuList2.setList(map(self.TSmediaMenu1_channels, []))
            return

    def keyDown(self):
       
        self['programm'].setText(' ')
        self[self.currentlist].down()
        itemindex = self[self.currentlist].getSelectionIndex()
        if self.currentlist == 'streamlist':
            self.streamMenuList2.setList(map(self.TSmediaMenu1_channels, []))
            return

    def keyRight(self):
        
        self['programm'].setText(' ')
        if self.currentlist == 'streamlist':
            self['streamlist2'].selectionEnabled(1)
            self['streamlist'].selectionEnabled(0)
            self.currentlist = 'streamlist2'
            return
        if self.currentlist == 'streamlist2':
            self['streamlist2'].selectionEnabled(0)
            self['streamlist'].selectionEnabled(1)
            self.currentlist = 'streamlist'

    def keyLeft(self):
       
        self['programm'].setText(' ')
        if self.currentlist == 'streamlist':
            self['streamlist2'].selectionEnabled(0)
            self['streamlist'].selectionEnabled(1)
            self.currentlist = 'streamlist'
            return
        if self.currentlist == 'streamlist2':
            self['streamlist2'].selectionEnabled(0)
            self['streamlist'].selectionEnabled(1)
            self.currentlist = 'streamlist'
            return

    def getchannels(self):
        self.timer2.stop()
        self.streamList2 = []
        itemindex = self[self.currentlist].getSelectionIndex()
        param = self.streamList[itemindex][1]
        print 'param', param
        from Plugins.Extensions.m3uPlayer.addons.iptv.m3uPlayer.default import process_mode
        param=param.replace("mode=1","mode=4")
        try:
            self.source_data = process_mode([], param)
        except:
           
            self['programm'].setText('Error loading channels..')
            return

        for item in self.source_data:
            self.streamList2.append((item[0], item[1], item[2]))

        self.streamMenuList2.setList(map(self.TSmediaMenu1_channels, self.streamList2))
        
        self['programm'].setText(' ')

    def keyOK(self):
        if self.currentlist == 'streamlist':
            title = self[self.currentlist].getCurrent()[0][0]
            param = self[self.currentlist].getCurrent()[0][1]
            itemindex = self[self.currentlist].getSelectionIndex()
            self.streamList2 = []
            if itemindex == 0:
                from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import getfav_datalist
                self.source_data = getfav_datalist('iptv/m3uPlayer', 'favorites')
                for item in self.source_data:
                    if item[1].startswith('http'):
                        self.streamList2.append((item[0], item[1], item[2]))

                self.streamMenuList2.setList(map(self.TSmediaMenu1_channels, self.streamList2))
                self['programm'].setText(' ')
            else:
                
                self['programm'].setText('Loading....... ')
                try:
                    self.timer2.callback.append(self.getchannels)
                except:
                    self.timer2_conn = self.timer2.timeout.connect(self.getchannels)

                self.timer2.start(20, 0)
            return
        if self.currentlist == 'streamlist2':
            try:
                title = self[self.currentlist].getCurrent()[0][0]
                param = self[self.currentlist].getCurrent()[0][1]
            except:
                return

            itemindex = self['streamlist2'].getSelectionIndex()
            bqindex = self['streamlist'].getSelectionIndex()
            if bqindex == 0:
                self.favmode = True
                self.sendback(itemindex, self.streamList2, bqindex, self.favmode)
            else:
                self.favmode = False
                self.sendback(itemindex, self.streamList2, bqindex - 1, self.favmode)

    def keyCancel(self):
        self.close(None, None, None)
        return
