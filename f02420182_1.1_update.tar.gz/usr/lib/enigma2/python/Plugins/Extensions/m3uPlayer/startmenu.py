# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/startmenu.py
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap, NumberActionMap
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
import xml.dom.minidom
import os
from Screens.MessageBox import MessageBox
from Components.Button import Button
from Tools.Directories import fileExists
from Components.ScrollLabel import ScrollLabel
from Components.Pixmap import Pixmap
from enigma import eTimer, eListboxPythonMultiContent, getDesktop, gFont, loadPNG
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from skin import parseColor
from Screens.Console import Console
import urllib
from Components.Label import Label
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import iPlayableService, iServiceInformation, eServiceReference, eListboxPythonMultiContent, getDesktop, gFont, loadPNG
from Tools.LoadPixmap import LoadPixmap
from Components.ConfigList import ConfigList, ConfigListScreen
from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import getversions2, gethostname, log
currversion, enigmaos, currpackage, currbuild = getversions2()
from Components.config import config
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer'
host=config.m3uPlayer.host.value
def readnet(url):
    import urllib2
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
   
    req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    
    response = urllib2.urlopen(req)
    link = response.read()
    return link


def cMenuListEntry(name, idx):
    name = ''
    res = [name]
    if idx == 0:
        idx = 'start'    
    elif idx == 1:
        idx = 'bouquets'
    elif idx == 2:
        idx = 'favorites'
    
    elif idx == 3:
        idx = 'software'
    elif idx == 4:
        idx = 'settings'        
    png = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/%s.png' % str(idx)
    if fileExists(png):
        if enigmaos == 'oe2.0':
            res.append(MultiContentEntryPixmapAlphaTest(pos=(2, 10), size=(237, 68), png=loadPNG(png)))
        else:
            res.append(MultiContentEntryPixmapAlphaTest(pos=(2, 10), size=(237, 68),png=loadPNG(png)))
    res.append(MultiContentEntryText(pos=(2, 3), size=(237, 90), font=0,border_width=3,border_color = 16776960, text=name))
    return res


menu_list = [_('start'),_('bouquets'), _('favorites'), _('software'), _('settings')]

def getAddonInfo(addon_id, item):
    xfile = PLUGIN_PATH + '/addons/' + addon_id + '/addon.xml'
    import xml.etree.cElementTree
    try:
        tree = xml.etree.cElementTree.parse(xfile)
    except:
        return {}

    root = tree.getroot()
    version = str(root.get('version'))
    provider = str(root.get('provider-name'))
    name = str(root.get('name'))
    desc = ''
    summ = ''
    id = str(root.get('id'))
    try:
        for description in root.iter('description'):
            desc = str(description.text)

    except:
        for description in root.getiterator('description'):
            desc = str(description.text)

    try:
        for summary in root.iter('summary'):
            summ = str(summary.text)

    except:
        for summary in root.getiterator('summary'):
            summ = str(summary.text)

    if item == 'path':
        return path
    elif item == 'version':
        return version
    elif item == 'provider':
        return provider
    elif item == 'name':
        return name
    elif item == 'id':
        return id
    elif item == 'profile':
        return profile
    elif item == 'description':
        return desc
    elif item == 'all':
        if desc == 'None':
            desc = ''
        return {'addon_id': addon_id,
         'name': name,
         'version': version,
         'provider': provider,
         'desc': desc}
    else:
        return {}


class ccMenuList(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setItemHeight(92)
        self.l.setFont(0, gFont('Regular', 25))


class m3uPlayerStartMenuscrn(Screen):
    global HD_Res
    try:
        sz_w = getDesktop(0).size().width()
        if sz_w == 1280:
            HD_Res = True
        else:
            HD_Res = False
    except:
        HD_Res = False

    skin = '''<screen  name="m3uPlayerStartMenuscrn" position="center,center" size="990,700" title=""  flags="wfNoBorder" >
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/framesd.png" position="0,0" size="990,700" transparent="1"/>	


	    <widget name="menu" position="23,155" size="245,500" scrollbarMode="showOnDemand" transparent="1" zPosition="2"  />
	        
            <widget name="status" position="485,170" zPosition="+2" size="25,25" alphatest="blend" />         
            <widget
            name = "info"
            position = "10,10"
            zPosition = "2"
            size = "990,140"
            font = "m3uPlayerFont;25"
            foregroundColor = "green"
            transparent = "1"
            halign = "center"
            valign = "center"/>

       
 

            
        </screen>'''
    def __init__(self, session, updateinfo = '1.1_False_1.1', plugin_name = 'm3uPlayer', back_close = None, active = False):
        Screen.__init__(self, session)
        self.session = session
        self.plugin_name = plugin_name
        self.active = True
        self.currversion, self.available_updates, self.newversion = ('1.1', 'False', '1.1')
        try:
            self.currversion, self.available_updates, self.newversion = updateinfo.split('_')
        except:
            pass

        self['status'] = Pixmap()
        self.softupdate = False
        if self.available_updates == 'False':
            self['info'] = Label(str(self.currversion))
        else:
            info = 'New release ' + self.newversion + ' is available press remote GREEN button to start upgrade'
            self.softupdate = True
            self['info'] = Label(str(info))
        try:    
            value=config.m3uPlayer.times.value
            if value<5:
               info='Copy your m3u file to /etc/m3uPlayer or if you have web link insert into /etc/m3uPlayer/iptvlist file'
               self['info'].setText(str(info))
               config.m3uPlayer.times.value=value+1
               config.m3uPlayer.times.save()
        except:
            pass

        self.color = '#00ffe875'
        self.transparent = True
        self['menu'] = ccMenuList([])
        self.working = False
        self.code = ''
        self.usercode = ''
        self['actions'] = NumberActionMap(['SetupActions', 'ColorActions'], {'ok': self.okClicked,
         'green': self.startupdate,
         'cancel': self.exit}, -2)
        self.lock = False
        self.timer = eTimer()
        self.timer2 = eTimer()
       
        if enigmaos == 'oe2.0':
                self.timer2_conn = self.timer2.callback.append(self.updateMenuList)
                self.timer2.start(100, 1)
        else:
                self.timer2_conn = self.timer2.timeout.connect(self.updateMenuList)
                self.timer2.start(100, 1)
    def exit(self):
        try:
            import shutil
            shutil.rmtree('/tmp/m3uPlayer')
        except:
            pass
        self.close()
        
    def startupdate(self):
        
       
        
        from lib.m3uPlayer_softupdate import m3uPlayerupdatesscreen
        self.session.open(m3uPlayerupdatesscreen)        

    def updateMenuList(self):
        self.timer2.stop()
        #if self.plugin_name == 'm3uPlayer':
            #statusicon = PLUGIN_PATH + '/skin/sicons/red_25.png'
            #self['status'].instance.setPixmapFromFile(statusicon)
            #return
        self.menu_list = []
        for x in self.menu_list:
            del self.menu_list[0]

        list = []
        idx = 0
        for x in menu_list:
            list.append(cMenuListEntry(x, idx))
            self.menu_list.append(x)
            idx += 1

        self['menu'].setList(list)
        
        


   
   

    def parseData(self, data):
        try:
            if data:
                try:sdata= data.split('"message":')[1].replace('"', '').replace('}', '')
                except:sdata=data
                if '100' in data:
                    self['info'].instance.setForegroundColor(parseColor('green'))
                    updatestatus('active')
                    

                    if self.softupdate == False:
                        self['info'].setText(str(sdata))
                    statusicon = PLUGIN_PATH + '/skin/spicons/green_25.png'
                    self['status'].instance.setPixmapFromFile(statusicon)
                    self['status'].instance.show()
                    updatestatus('active')
                else:
                    updatestatus('inactive')
                    if self.softupdate == False:
                        self['info'].setText(str(sdata))
                    self['info'].instance.setForegroundColor(parseColor('red'))
                    statusicon = PLUGIN_PATH + '/skin/spicons/red_25.png'
                    self['status'].instance.setPixmapFromFile(statusicon)
                    self['status'].instance.show()
        except:
            pass

        self.onShow.append(self.refresh_status)

    def loadaccountinfo(self):
        self.timer.stop()
        from lib.screens.accountinfo import m3uPlayeraccount
        self.session.open(m3uPlayeraccount)

    def refresh_status(self):
        try:
            if self.available_updates == 'True':
                self.available_updates = 'False'
                return
            self['info'].setText(self.currversion)
            if os.path.exists('/tmp/m3uPlayer/status') == True:
                try:
                    txt = open('/tmp/m3uPlayer/status').read().strip()
                except:
                    txt = 'inactive'

                if txt == 'active':
                    self['info'].instance.setForegroundColor(parseColor('green'))
                    statusicon = PLUGIN_PATH + '/skin/spicons/green_25.png'
                    self['status'].instance.setPixmapFromFile(statusicon)
                else:
                    self['info'].instance.setForegroundColor(parseColor('red'))
                    statusicon = PLUGIN_PATH + '/skin/spicons/red_25.png'
                    self['status'].instance.setPixmapFromFile(statusicon)
        except:
            statusicon = PLUGIN_PATH + '/skin/spicons/red_25.png'
            self['status'].instance.setPixmapFromFile(statusicon)
            self['status'].instance.show()

    def Showabout(self):
        self.session.open(classicAboutScreen)

    def ShowFavorites(self):
        self.session.open(classicFavoritescrn)

    def Addstation(self):
        self.session.open(classicStationsScreen)

    def okClicked(self):
        self.keyNumberGlobal(self['menu'].getSelectedIndex())
    def updateindex(self,reult=None):
        return
    def keyNumberGlobal(self, idx):
        if self.plugin_name == 'brothershd':
            self.close()
            return
        elif self.lock == True:
            return
        else:
            sel = self.menu_list[idx]
            
        if True:
            if sel == _('start'):        
                    try:
                        import ast
                        playlist_file='/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/playlist'
                        lines=open(playlist_file).readlines()
                        
                        playlist=ast.literal_eval(lines[0])

                        bqindex=int(lines[1])
                        playindex=int(lines[2])
                        if 'False' in lines[3]:
                            favmode=False
                        else:
                            favmode=True
                        print  'playlistp',playlist   
                        param=playlist[playindex][1]
                        name=playlist[playindex][0]
                    except:
                        playlist=[]
                        bqindex=0
                        playindex=0
                        favmode=False
                        param=''
                        name=''
                    print "favmode",favmode
                    from Plugins.Extensions.m3uPlayer.lib.TSplayer import TSplayer
                    self.session.openWithCallback(self.updateindex,TSplayer, serviceRef=None,serviceUrl=str(param),serviceName=name,serviceIcon='', playlist = playlist, playindex =playindex,bqindex=bqindex,favmode=favmode)    			
                                    

            elif sel == _('favorites'):
                try:
                    from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import getfav_datalist
                    self.section = 'iptv'
                    section = 'iptv'
                    source_data = getfav_datalist(addon_id=self.section + '/SFavorites', section=self.section, mode='section')
                    from Plugins.Extensions.m3uPlayer.lib.screens.plugin4 import m3uPlayerScreen4
                    self.session.open(m3uPlayerScreen4, {'addon_id': section + '/SFavorites',
                     'section': section,
                     'name': 'SFavorites'}, '', source_data, 1, [])
                    return
                    self.session.open(classicFavoritescrn)
                except:
                    self.section = 'iptv'
                    addons_path = PLUGIN_PATH + '/addons/' + self.section + '/'
                    addon_id = 'iptv/m3uPlayer'
                    from lib.screens.plugin6 import m3uPlayerScreen11_p as MediaScreen4
                    info = getAddonInfo(addon_id, 'all')
                    info['name'] = 'favorites'
                    self.session.open(MediaScreen4, info=info, action_params=None, source_data=[], nextrun=1, screens=[])
            elif sel == _('bouquets'):
                self.section = 'iptv'
                addons_path = PLUGIN_PATH + '/addons/' + self.section + '/'
                addon_id = 'iptv/m3uPlayer'
                from lib.screens.plugin6 import m3uPlayerScreen11_p as MediaScreen4
                info = getAddonInfo(addon_id, 'all')
                self.session.open(MediaScreen4, info=info, action_params=None, source_data=[], nextrun=1, screens=[])
            elif sel == _('login'):
                self.startlogin()
            elif sel == _('software'):
                from lib.m3uPlayer_softupdate import m3uPlayerupdatesscreen
                self.session.open(m3uPlayerupdatesscreen)
            elif sel == _('settings'):
                from lib.m3uPlayerSetup import m3uPlayerSetup
                self.session.open(m3uPlayerSetup)


            return





def updatestatus(txt):
    try:
        afile = open('/tmp/m3uPlayer/status', 'w')
        afile.write(txt)
        afile.close()
    except:
        pass




