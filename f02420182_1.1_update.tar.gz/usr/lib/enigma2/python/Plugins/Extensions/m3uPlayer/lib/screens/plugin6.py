# 2015.06.05 13:08:33 Jordan Daylight Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/plugin.py
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer'
#mytubepath = PLUGIN_PATH + '/addons/youtube/TSTube/tstube_default.py'


import os
import sys
import shutil

from twisted.web.client import downloadPage, getPage, error

from os import listdir as os_listdir
from Screens.Standby import TryQuitMainloop
#from twisted.web.client import downloadPage, getPage, error
from twisted.web import client
import re, urllib2, urllib, cookielib, socket
from urllib2 import Request, URLError, urlopen as urlopen2, build_opener, HTTPCookieProcessor, HTTPHandler, quote, unquote
from urllib import quote, unquote_plus, unquote, urlencode
from httplib import HTTPConnection, CannotSendRequest, BadStatusLine, HTTPException
import httplib
from urlparse import urlparse, parse_qs
from xml.dom.minidom import parse
import StringIO
from random import randint
from xml.dom import Node, minidom
from Plugins.Plugin import PluginDescriptor
from enigma import getPrevAsciiCode,eDVBDB, gPixmapPtr, eConsoleAppContainer, eSize, ePoint, eTimer, addFont, loadPNG, quitMainloop, eListbox, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont, getDesktop, ePicLoad, eServiceCenter, iServiceInformation, eServiceReference, iSeekableService, iPlayableService, iPlayableServicePtr, eDVBDB
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBar import InfoBar
from Screens.MessageBox import MessageBox
from Screens.InfoBarGenerics import *
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.Label import Label
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Sources.List import List
from Components.Button import Button
from Components.Pixmap import Pixmap, MovingPixmap
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Sources.StaticText import StaticText
from Components.AVSwitch import AVSwitch
from Components.ScrollLabel import ScrollLabel
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, pathExists, SCOPE_MEDIA, copyfile, fileExists, createDir,  SCOPE_PLUGINS, SCOPE_CURRENT_SKIN

import sys



from GlobalActions import globalActionMap

from Screens.InfoBarGenerics import InfoBarPlugins

InfoBar_instance = None

def getScale():
    return AVSwitch().getFramebufferScale()


from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmap, MultiContentEntryPixmapAlphaTest
from Components.config import config, ConfigInteger, ConfigDirectory, ConfigSubsection, ConfigSubList, ConfigEnableDisable, ConfigNumber, ConfigText, ConfigSelection, ConfigYesNo, ConfigPassword, getConfigListEntry, configfile
from Components.ConfigList import ConfigListScreen
from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import getversions2,gethostname,log
currversion,enigmaos,currpackage,currbuild= getversions2()
def getfreespace(downloadlocation = None):
    if os.path.exists(downloadlocation) == False:
        return (0, 'Download location is not available')
    else:
        try:
            diskSpace = os.statvfs(downloadlocation)
            capacity = float(diskSpace.f_bsize * diskSpace.f_blocks)
            available = float(diskSpace.f_bsize * diskSpace.f_bavail)
            fspace = round(float(available / 1048576.0), 2)
            tspace = round(float(capacity / 1048576.0), 1)
            spacestr = 'Free space(' + str(fspace) + 'MB) Total space(' + str(tspace) + 'MB)'
            return (fspace, spacestr)
        except:
            return (None, None)

        return None
       



T_INDEX = 0
T_FRAME_POS = 1
T_PAGE = 2
T_NAME = 3
T_FULL = 4


def startspinner():
                from Spinner import Spinner
                cursel = PLUGIN_PATH+"/skin/spinner"
    		Bilder = []
		if cursel:
			for i in range(30):
				if (os.path.isfile("%s/wait%d.png"%(cursel,i+1))):
					Bilder.append("%s/wait%d.png"%(cursel,i+1))
		else:
		        Bilder = []
                #self["text"].setText("Press ok to exit")
                return Spinner(Bilder)             
def buildBilder():
                cursel = PLUGIN_PATH+"/skin/spinner"
    		Bilder = []
		if cursel:
			for i in range(30):
				if (os.path.isfile("%s/wait%d.png"%(cursel,i+1))):
					Bilder.append("%s/wait%d.png"%(cursel,i+1))
		else:
		        Bilder = []
                #self["text"].setText("Press ok to exit")
                
                return Bilder
class m3uPlayerScreen11_p(Screen):                                                        
    #def __init__(self, session, info={},param_title=None,action_params=None,source_data=[],nextrun=1,isplayable=False,predata_source=[],close_back=None,screens=[],group_title=''):
    def __init__(self, session,info={},action_params=None,source_data=[],nextrun=1,screens=[],bqindex=0):  
        self.action_params=action_params
       
        try:param_title=info['name']
        except:param_title='m3uPlayer'
        self.param_title= param_title
       
        self.bqindex=bqindex
        #self["bild"] = startspinner()
        self.firstpage_title=param_title
        self.session = session
        
        self.screens=screens
        self.screens.append(self)       
        self.updates_available=False
        self.lock =False
        self.update=False
        lock=False
        self.preindex=20
        self.info=info
        currversion=' '# currkernel, currpackage, currbuild = getversions2()
        currversionstr =' '# currversion
        self.transparent = True
        try:self.plugin_id=info['addon_id']
        except:self.plugin_id=None
        self.addon_id=self.plugin_id
        try:self.section=self.plugin_id.split("/")[0]
        except:self.section=None
        try:self.description=info['description']
        except:self.description='' 
        try:self.metadata=info['metadata']
        except:self.metadata=False        
        try:self.addon_version=info['version']
        except:self.addon_version=''               
        self.long_plugin_id=self.plugin_id
        try: self.fanart=info['fanart']
        except:self.fanart=False
        if config.m3uPlayer.fanart.value==False:
           self.fanart=False
        self.fanart=True  
        self.fanart_file=PLUGIN_PATH+"/skin/icons/framesd.png"
        if os.path.exists(self.fanart_file) and self.fanart==True:
           self.fanart=True
        else:
           self.fanart=False   
        currversionstr =  '  '#currversion
        try:
          textsize=int(info['textsize'])
        except:
          try:textsize=int(config.m3uPlayer.label_textsize.value)
          except:textsize=20
        try:
          self.textcolor=str(info['textcolor'])
        except:
          try:self.textcolor=str(config.m3uPlayer.textcolor.value)
          except:self.textcolor='#76addc'   
        fonttype='m3uPlayerFont'
        self.spinner_running=False
        #self.textcolor = config.m3uPlayer.textcolor.value
        self.color = '#080000'#config.m3uPlayer.bgcolor.value
        dwidth = getDesktop(0).size().width()
        size_w = getDesktop(0).size().width()
        size_h = getDesktop(0).size().height()
        if dwidth == 1280:
            size_w = 1000
            size_h = 702
            #textsize = 20
            self.spaceX = 100#130#35
            self.picX = 220#200#180
            self.spaceY = 20#50
            self.picY = 170
        elif dwidth == 1920:
            size_w = 1500
            size_h = 1050
            textsize = 45
            self.spaceX = 150#130#35
            self.picX = 330#200#180
            self.spaceY = 30#50
            self.picY = 255
        else:
            #textsize = 20
            self.spaceX = 75#30
            self.picX = 205#185
            self.spaceY = 40
            self.picY = 156
        self.thumbsX = 3
        self.thumbsY = 3
        self.thumbsC = self.thumbsX * self.thumbsY
        
        skincontent = ''
        posX = -1
        self.positionlist=[]
        if dwidth == 1920:
           if enigmaos=='oe2.0':
                  for x in range(self.thumbsC):
                      posY = x / self.thumbsX
                      posX += 1
                      if posX >= self.thumbsX:
                          posX = 0
                      absX = self.spaceX + posX * (self.spaceX + self.picX)
                      absY = 55 + posY * (30 + self.picY)
                      self.positionlist.append((absX, absY))##-125 -20
                      skincontent += '<widget source="label' + str(x) + '" render="Label" position="' + str(absX - 70) + ',' + str(absY + self.picY - 20) + '" size="' + str(self.picX + 120) + ',' + str(2*textsize) + '" font="m3uPlayerFont;30" zPosition="10" transparent="1"  halign="' + 'center' + '"  valign="' + 'center' + '"  foregroundColor="' + self.textcolor + '" />'
                      skincontent += '<widget name="thumb' + str(x) + '" position="' + str(absX + 7) + ',' + str(absY + 15) + '" size="' + str(self.picX - 45) + ',' + str(self.picY - 30) + '" zPosition="10"  alphatest="on" />'
                  skincontent +='<widget name="handlung" position="1536,680" size="330,513" backgroundColor="#080000" transparent="1" font="m3uPlayerFont;30" valign="top" halign="center" zPosition="1" />'
                  skincontent +='<widget name="info" position="1553,450" zPosition="4" size="330,225" font="m3uPlayerFont;30" foregroundColor="yellow" transparent="1" halign="left" valign="top" />'
                  skincontent +='<widget name="fanArt" position="250,150" transparent="1" zPosition="2" size="1000,702"/>'	
                             
                  skincontent +='''
                      <ePixmap position="1530,625" size="410,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hsyoutubefhd.png"    alphatest="blend" />
                        
                      <ePixmap position="20,1050" size="1920,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutubefhd.png"    alphatest="blend" />
                      
                      <ePixmap position="20,20" size="1920,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutubefhd.png"    alphatest="blend" />
                                      
                      <ePixmap position="1900,20" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" />
                      <ePixmap position="20,20" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" /> 
                      <ePixmap position="1500,20" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" /> 
                      
                      
                       <ePixmap position="1545,77" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                      <ePixmap position="1545,172" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />                
                      <ePixmap position="1545,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                      <ePixmap position="1545,345" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                       
                      <ePixmap position="1557,97" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/red.png"    zPosition="3" transparent="1" alphatest="blend" />
                      <ePixmap position="1557,177" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"  zPosition="3" transparent="1" alphatest="blend" />	
                      <ePixmap position="1557,270" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/yellow.png"    zPosition="3" transparent="1" alphatest="blend" />
                      <ePixmap position="1557,350" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/blue.png"  zPosition="3" transparent="1" alphatest="blend" />                
                       
                      <ePixmap position="1600,950" size="171,171" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/m3uPlayer.png"  zPosition="3" transparent="1" alphatest="blend" />                
                       

                      <eLabel position="1500,97" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000" text="Menu" />
                      
                      <widget name="Key_green" position="1500,190" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="Key_yellow" position="1500,283" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="Key_blue" position="1500,363" zPosition="4" size="290,36"  halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="page" position="30,1010" zPosition="4" size="960,90" font="m3uPlayerFont;30" foregroundColor="yellow" transparent="1" halign="center" valign="top" />

                      '''
                      
                                  
         
         
              
                  if self.lock == True:
                      self.close()
                     
                 
                  self.skin = '<screen position="center,center"    size="' + str(1920) + ',' + str(1070) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="600,990" zPosition="3" size="' + str(105) + ',' + str(52) + '" foregroundColor="' + self.textcolor + '" backgroundColor="' + '#080000' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;20' + '" text="' + '' + str(currversion) + '" /><widget name="frame" position="30,30" size="300,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/pic_frame2fhd.png" zPosition="10" alphatest="on" />' + skincontent + '</screen>'
                 
                 
           else:#enigmaos2.2
                  for x in range(self.thumbsC):
                      posY = x / self.thumbsX
                      posX += 1
                      if posX >= self.thumbsX:
                          posX = 0
                      absX = self.spaceX + posX * (self.spaceX + self.picX)
                      absY = 55 + posY * (30 + self.picY)
                      self.positionlist.append((absX, absY))##-90 -15
                      skincontent += '<widget source="label' + str(x) + '" render="Label" position="' + str(absX - 80) + ',' + str(absY + self.picY - 25) + '" size="' + str(self.picX + 120) + ',' + str(2*textsize) + '" font="m3uPlayerFont;30" zPosition="10" transparent="1"  halign="' + 'center' + '"  valign="' + 'center' + '"  foregroundColor="' + self.textcolor + '" />'
                      skincontent += '<widget name="thumb' + str(x) + '" position="' + str(absX + 7) + ',' + str(absY + 15) + '" size="' + str(self.picX - 45) + ',' + str(self.picY - 30) + '" zPosition="10"  alphatest="on" />'
                  skincontent +='<widget name="handlung" position="1536,680" size="330,513" backgroundColor="#080000" transparent="1" font="m3uPlayerFont;30" valign="top" halign="center" zPosition="1" />'
                  skincontent +='<widget name="info" position="1553,410" zPosition="4" size="330,225" font="m3uPlayerFont;30" foregroundColor="yellow" transparent="1" halign="left" valign="top" />'
                  skincontent +='<widget name="fanArt" position="250,150" transparent="1" zPosition="2" size="1000,702"/>'	
                             
                  skincontent +='''
                     

<ePixmap position="1530,535" size="410,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hsyoutubefhd.png"    alphatest="blend" />
                  
                <ePixmap position="0,1065" size="1920,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutubefhd.png"    alphatest="blend" />
                
                <ePixmap position="0,10" size="1920,33" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutubefhd.png"    alphatest="blend" />
                                
                <ePixmap position="1900,0" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" />
                <ePixmap position="0,33" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" /> 
                <ePixmap position="1500,0" size="33,1065" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutubefhd.png"    alphatest="blend" /> 
		


               <ePixmap position="1600,950" size="171,171" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/m3uPlayer.png"  zPosition="3" transparent="1" alphatest="blend" />                
                       

                      
                       <ePixmap position="1545,77" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                      <ePixmap position="1545,172" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />                
                      <ePixmap position="1545,265" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                      <ePixmap position="1545,345" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="306,55" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                       
                      <ePixmap position="1557,97" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/red.png"    zPosition="3" transparent="1" alphatest="blend" />
                      <ePixmap position="1557,177" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"  zPosition="3" transparent="1" alphatest="blend" />	
                      <ePixmap position="1557,270" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/yellow.png"    zPosition="3" transparent="1" alphatest="blend" />
                      <ePixmap position="1557,350" size="37,37" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/blue.png"  zPosition="3" transparent="1" alphatest="blend" />                
                       
                      

                      <eLabel position="1602,97" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000" text="Menu" />
                      
                      <widget name="Key_green" position="1602,190" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="Key_yellow" position="1602,283" zPosition="4" size="290,36" halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="Key_blue" position="1602,363" zPosition="4" size="290,36"  halign="center" font="m3uPlayerFont;27" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                      <widget name="page" position="30,1010" zPosition="4" size="960,90" font="m3uPlayerFont;30" foregroundColor="yellow" transparent="1" halign="center" valign="top" />
                      '''
                      
                                  
         
         
              
                  if self.lock == True:
                      self.close()
                     
                 
                  self.skin = '<screen position="center,center"    size="' + str(1920) + ',' + str(1070) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="600,990" zPosition="3" size="' + str(105) + ',' + str(52) + '" foregroundColor="' + self.textcolor + '" backgroundColor="' + '#080000' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;20' + '" text="' + '' + str(currversion) + '" /><widget name="frame" position="30,30" size="290,240" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/pic_frame2fhd.png" zPosition="10" alphatest="on" />' + skincontent + '</screen>'
                 
        else:
          if enigmaos=='oe2.0':
            for x in range(self.thumbsC):
                posY = x / self.thumbsX
                posX += 1
                if posX >= self.thumbsX:
                    posX = 0
                absX = self.spaceX + posX * (self.spaceX + self.picX)
                absY = 55 + posY * (30 + self.picY)
                self.positionlist.append((absX, absY))
                skincontent += '<widget source="label' + str(x) + '" render="Label" position="' + str(absX - 70) + ',' + str(absY + self.picY-5) + '" size="' + str(self.picX + 90) + ',' + str(2*textsize) + '" font="'+fonttype+';'+str(textsize)+'" zPosition="10" transparent="0"  halign="' + 'center' + '"  valign="' + 'center' + '"  foregroundColor="' + self.textcolor + '" />'
                skincontent += '<widget name="thumb' + str(x) + '" position="' + str(absX + 5) + ',' + str(absY + 10) + '" size="' + str(self.picX - 30) + ',' + str(self.picY - 20) + '" zPosition="10"  alphatest="on" />'
                skincontent +='<widget name="handlung" position="1024,380" size="220,278" backgroundColor="#080000" transparent="1" font="m3uPlayerFont;20" valign="top" halign="center" zPosition="1" />'
                skincontent +='<widget name="info" position="1035,275" zPosition="4" size="220,150" font="m3uPlayerFont;20" foregroundColor="yellow" transparent="1" halign="left" valign="top" />'
                #if self.fanart==True:
                   #skincontent +='<ePixmap pixmap='+'"'+fanart_file+'"'+' position="0,0" size="1000,702"/>'	
                skincontent +='<widget name="fanArt" position="0,0" transparent="1" zPosition="2" size="1000,730"/>'	
            
            skincontent +='''
                <ePixmap position="1020,340" size="238,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hsyoutube.png"    alphatest="blend" />
                  
                <ePixmap position="0,700" size="1280,22" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutube.png"    alphatest="blend" />
                
                <ePixmap position="0,0" size="1280,22" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutube.png"    alphatest="blend" />
                                
                <ePixmap position="1260,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" />
                <ePixmap position="0,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" /> 
                <ePixmap position="1000,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" /> 
		<ePixmap position="1030,53" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                <ePixmap position="1030,115" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />                
                <ePixmap position="1030,177" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
		<ePixmap position="1030,230" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
		 
		<ePixmap position="1038,56" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/red.png"    zPosition="3" transparent="1" alphatest="blend" />
		<ePixmap position="1038,118" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"  zPosition="3" transparent="1" alphatest="blend" />	
		<ePixmap position="1038,180" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/yellow.png"    zPosition="3" transparent="1" alphatest="blend" />
		<ePixmap position="1038,233" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/blue.png"  zPosition="3" transparent="1" alphatest="blend" />                
		 
		<ePixmap position="1080,620" size="171,172" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/m3uPlayer.png"  zPosition="3" transparent="1" alphatest="blend" />                
                       

                <eLabel position="1068,65" zPosition="4" size="140,24" halign="center" font="m3uPlayerFont;20" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000" text="Menu" />
		
		<widget name="Key_green" position="1068,127" zPosition="4" size="160,24" halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                <widget name="Key_yellow" position="1068,189" zPosition="4" size="160,24" halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
		<widget name="Key_blue" position="1068,242" zPosition="4" size="160,24"  halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />'
                <widget name="page" position="20,680" zPosition="4" size="440,60" font="m3uPlayerFont;20" foregroundColor="yellow" transparent="1" halign="center" valign="top" />
                '''
                
            
            
            if True:
               
                    self.skin = '<screen position="center,center"    size="' + str(1280) + ',' + str(720) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="400,660" transparent="1" zPosition="3" size="' + str(70) + ',' + str(35) + '" foregroundColor="' + self.textcolor + '" backgroundColor="' + '#080000' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;20' + '" text="' + '' + str(currversion) + '" /><widget name="frame" position="20,20" size="200,156" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/pic_frame2.png" zPosition="10" alphatest="on" />' + skincontent + '</screen>'
          else:#oe2.2


            for x in range(self.thumbsC):
                posY = x / self.thumbsX
                posX += 1
                if posX >= self.thumbsX:
                    posX = 0
                absX = self.spaceX + posX * (self.spaceX + self.picX)
                absY = 55 + posY * (30 + self.picY)
                self.positionlist.append((absX, absY))
                skincontent += '<widget source="label' + str(x) + '" render="Label" position="' + str(absX - 50) + ',' + str(absY + self.picY-5) + '" size="' + str(self.picX + 90) + ',' + str(2*textsize) + '" font="'+fonttype+';'+str(textsize)+'" zPosition="10" transparent="0"  halign="' + 'center' + '"  valign="' + 'center' + '"  foregroundColor="' + self.textcolor + '" />'
                skincontent += '<widget name="thumb' + str(x) + '" position="' + str(absX + 5) + ',' + str(absY + 10) + '" size="' + str(self.picX - 30) + ',' + str(self.picY - 20) + '" zPosition="10"  alphatest="on" />'
                skincontent +='<widget name="handlung" position="1024,380" size="220,278" backgroundColor="#080000" transparent="1" font="m3uPlayerFont;20" valign="top" halign="center" zPosition="1" />'
                skincontent +='<widget name="info" position="1035,275" zPosition="4" size="220,150" font="m3uPlayerFont;20" foregroundColor="yellow" transparent="1" halign="left" valign="top" />'
                #if self.fanart==True:
                   #skincontent +='<ePixmap pixmap='+'"'+fanart_file+'"'+' position="0,0" size="1000,702"/>'	
                skincontent +='<widget name="fanArt" position="0,0" transparent="1" zPosition="2" size="1000,730"/>'	
            
            skincontent +='''
                <ePixmap position="1020,340" size="238,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hsyoutube.png"    alphatest="blend" />
                  
                <ePixmap position="0,700" size="1280,22" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutube.png"    alphatest="blend" />
                
                <ePixmap position="0,0" size="1280,22" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/hyoutube.png"    alphatest="blend" />
                                
                <ePixmap position="1260,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" />
                <ePixmap position="0,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" /> 
                <ePixmap position="1000,0" size="22,714" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/vyoutube.png"    alphatest="blend" /> 
		<ePixmap position="1030,53" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
                <ePixmap position="1030,115" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />                
                <ePixmap position="1030,177" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
		<ePixmap position="1030,230" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/tab_active.png" size="204,37" zPosition="2" backgroundColor="#ffffff" alphatest="blend" />
		 
		<ePixmap position="1038,56" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/red.png"    zPosition="3" transparent="1" alphatest="blend" />
		<ePixmap position="1038,118" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/green.png"  zPosition="3" transparent="1" alphatest="blend" />	
		<ePixmap position="1038,180" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/yellow.png"    zPosition="3" transparent="1" alphatest="blend" />
		<ePixmap position="1038,233" size="25,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/blue.png"  zPosition="3" transparent="1" alphatest="blend" />                
		 
                <ePixmap position="1080,620" size="171,171" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/icons/m3uPlayer.png"  zPosition="3" transparent="1" alphatest="blend" />                
                		

                <eLabel position="1068,65" zPosition="4" size="140,24" halign="center" font="m3uPlayerFont;20" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000" text="Menu" />
		
		<widget name="Key_green" position="1068,127" zPosition="4" size="160,24" halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
                <widget name="Key_yellow" position="1068,189" zPosition="4" size="160,24" halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />
		<widget name="Key_blue" position="1068,242" zPosition="4" size="160,24"  halign="center" font="m3uPlayerFont;18" transparent="1" foregroundColor="#ffffff" backgroundColor="#41000000"  />'
                <widget name="page" position="20,680" zPosition="4" size="440,60" font="m3uPlayerFont;20" foregroundColor="yellow" transparent="1" halign="center" valign="top" />
                '''
                
          
           
            if True:
                
                    self.skin = '<screen position="center,center"    size="' + str(1280) + ',' + str(720) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="400,660" transparent="1" zPosition="3" size="' + str(70) + ',' + str(35) + '" foregroundColor="' + self.textcolor + '" backgroundColor="' + '#080000' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;20' + '" text="' + '' + str(currversion) + '" /><widget name="frame" position="20,20" size="200,156" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/pic_frame2.png" zPosition="10" alphatest="on" />' + skincontent + '</screen>'
          







            
            
            #elif plugin_skin == '0':
                #self.skin = '<screen position="center,center" flags="wfNoBorder" title="' + str(currversionstr) + '"  size="' + str(size_w) + ',' + str(size_h) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="370,665" zPosition="2" size="' + str(70) + ',' + str(35) + '" foregroundColor="' + self.textcolor + '" transparent="' + '1' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;20' + '" text="' + '' + str(currversion) + '" /><widget name="frame" position="20,20" size="145,145" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TSTube/skin/images/pic_frame.png" zPosition="1" alphatest="on" /><ePixmap  position="0,0" size="852,702" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TSTube/skin/images/framepanel.png" zPosition="1" alphatest="on" /><widget name="updates" position="300,10" size="31,31" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TSTube/skin/spicons/updates.png" zPosition="2" alphatest="on" />' + skincontent + '</screen>'
            #else:
                #self.skin = '<screen position="center,center"    size="' + str(size_w) + ',' + str(size_h) + '" > \t\t\t<eLabel position="0,0" zPosition="0" size="' + str(size_w) + ',' + str(size_h) + '" backgroundColor="' + self.color + '" /><eLabel position="0,620" zPosition="1" size="' + str(665) + ',' + str(35) + '" foregroundColor="' + 'red' + '" backgroundColor="' + '#080000' + '" halign="' + 'center' + '"  valign="' + 'center' + '"  font="' + 'm3uPlayerFont;22' + '" text="' + '' + str(currversionstr) + '" /><widget name="frame" position="20,20" size="145,145" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TSTube/skin/images/pic_frame.png" zPosition="1" alphatest="on" /><widget name="updates" position="588,580" size="31,31" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TSTube/skin/sicons/updates.png" zPosition="1" alphatest="on" />' + skincontent + '</screen>'
        Screen.__init__(self, session)
        self.onShow.append(self.refresh)
        ##m3uPlayer stuff
        
        self.nextrun=nextrun##cancelled
        self.page=nextrun
        self.currPage=0
        self.favmode=False
        self.source_data=source_data
        self.predata_source=[]
        self.favplaylist=[]
        self.playlist=[]
        self.param_title=param_title
        self.param_url=action_params
        self.action_params=action_params
        self.close_back=None		


        
        self.bouquet=False        


       
        self['handlung'] = Label("Please wait... ")
        self.startSpinner()
        self['page']=Label()
        self['info'] = Label(str(self.page))
        self['fanArt'] =Pixmap()
        self.pages=[]
        #self.etag='none'
        #self.pages.((self.page,self.action_params,self.group_title,self.etag))

        if not os.path.exists("/tmp/m3uPlayer/"):
             os.makedirs("/tmp/m3uPlayer/")
        self["Key_green"]=Label("Update")

        self.data1=[]
        self.data1.append(('',[]))
        self.index=0
        try:curraction_params=self.source_data[0][1]
        except:curraction_params=''
       
           
            
        
           
        self["Key_green"]=Label(" ")
        self["Key_blue"]=Label(" ")
        self.update=False
        self.bouquet=False
        self.convert=False
                    
         
        self.favmode=False
        
        if (self.param_title=='Gplaylist' or self.param_title=='Favorites' or self.param_title=='GFavorites' or self.param_title=='SFavorites') and self.page==1:
           self.sender='favorites'
           self["Key_yellow"]=Label("Delete")
           self["Key_blue"]=Label("+Bouquet")
           
           
           self.favmode=True
           
        else:
        
                       
            self["Key_yellow"]=Label("+Favorite")
        
        #if self.group_title=='Favorites'and self.page==1:
           #self["Key_yellow"]=Label("Remove")
        #else:                   
           #self["Key_yellow"]=Label(" + Favorite")



           
        self.data=''
        self.rundef=None
        self.keyLocked=False
        self.resultsperpage=45
        self["Key_blue"]=Label("M3u2Bouquet")
        self.showdownload=True          
        self.download=False
        
        ##
        self['actions'] = ActionMap(['ColorActions','OkCancelActions',
         'DirectionActions',
         'MovieSelectionActions','MenuActions',"EPGSelectActions",'WizardActions','PiPSetupActions'], {"red":self.closeall,			
         "yellow":self.savetofavorites,
         "blue":self.exportchannels,
         "green":self.update_bqs ,#self.addfavorite,
         "ok": self.ok_clicked,         
         'cancel': self.exit,
         'left': self.key_left,
         'right': self.key_right,
       
         'size+': self.previouspage,
         'size-': self.nextpage,               
         'up': self.key_up,
         'down': self.key_down}, -1)

        self['frame'] = MovingPixmap()
        for x in range(self.thumbsC):
            self['label' + str(x)] = StaticText()
            self['thumb' + str(x)] = Pixmap()
        self.maxentry=12
        self.preindex=0
        self.convert=False
        self.bqupdate=False
       	self.keyLocked = True
        self.onLayoutFinish.append(self.load_bqs)
        self.timer = eTimer()
                    
    def refresh(self):
        #self.stopSpinner()
        self.keyLocked = False
        #self.download=False
        
    def update_bqs(self):
        import os
        
        if self.update==False:
            self.search_ch()
            return

        try:
            try:title=str(self.data[self.index][0])
            except:pass            
            itempath="/etc/m3uPlayer/"+title+".lnk"
            link=open(itempath).read().strip()
            folder="/etc/m3uPlayer/"
            if os.path.exists(itempath):
               urllib.urlretrieve(link, folder + title + '.m3u')
               self['handlung'].setText("m3u file is updated successfully")
            else:
               self['handlung'].setText("No source link file available")
               return
        except:
            self['handlung'].setText("Unable to update m3u file")
            return
        self.bqupdate=True
        self.load_bqs()
        
    def load_bqs(self):
        #fanart='"/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/images/fanart.jpg'
        #####iptvalgeria
        
        

        if self.fanart:
           self.showPic(pic=self['fanArt'],picfile=self.fanart_file)
           
        self.startSpinner()
        self.loaddata()   
    def showgensettings(self):
        from Plugins.Extensions.m3uPlayer.plugin import m3uPlayerSetup1
        self.session.open(m3uPlayerSetup1)    
    
        
    def showinformation(self):
            self.allow=True
            from Plugins.Extensions.m3uPlayer.lib.m3uPlayerinfo import m3uPlayerinfoscreen
            self.session.open(m3uPlayerinfoscreen,self.addon_id)  
        
    def startSpinner(self):
        return
        print "self.spinner_running",self.spinner_running
        if self.spinner_running==False:
          Bilder=buildBilder()
          self["bild"].start(Bilder)
          self.spinner_running=True
          return    
    def stopSpinner(self):
       return
       try:
         if self.spinner_running==True:
          self["bild"].stop()
          self.spinner_running=False                   
          self['bild'].instance.setPixmap(gPixmapPtr())     
          
          
          
   
         return 
       except:
         return             

    #self['bild']=None            
    def progress_callback(self,result):
          try:
            if result:
              if result.startswith("Error"):
               
                 self.keyLocked=False
                 self.stopSpinner()
                 self['handlung'].setText(str(result))  
                 pass
              if result.startswith("Complete"):
                 self.keyLocked=False
                 self.stopSpinner()
                 self.updateinfo()
          except:
              
              pass   
           
    def exitpages(self):
       if self.spinner_running==True:
              self.stopSpinner()
              
           
       else:
           self.stopSpinner() 
         
       self.close()   
    def loaddata(self):
        try:self.timer.stop()
        except:pass    
        self['handlung'].setText("Please wait.. ")
               
        try:
            self.timer_connect=self.timer.timeout.connect(self.startloaddata)
        except:
            self.timer.callback.append(self.startloaddata)
        self.timer.start(10, 1) 
    def datalist(self):
      
        self.data=[]
        
        if self.param_title.lower()=='favorites':
                from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import getfav_datalist
                self.data=getfav_datalist('iptv/m3uPlayer','favorites')     
                
        
                self["Key_yellow"].setText("Remove")
                self["Key_blue"].setText("+Bouquet")
                self.bouquet=True
                self.favmode=True
                                            
                 
        else:

            if len(self.source_data)<1 and not self.param_title=='Favorites' and not self.param_title=='GFavorites'  and not self.param_title=='SFavorites':
                                 #self['handlung'].setText('please wait..')
                                 pass
                                 self.lock=True
                                 self['handlung'].setText('Please wait..') 
                                 
                                 
                                 
                                
                                 from Plugins.Extensions.m3uPlayer.addons.iptv.m3uPlayer.default import process_mode
                                 
                                 log("self.action_params",self.action_params)
                                 print "self.action_params",self.action_params
                                 self.source_data =process_mode([],self.action_params)
                                 print "self.source_data",self.source_data


             
            self.data=self.source_data#process_request(self.action_params)
            self["Key_yellow"].setText(" + Favorite")
                                     
        try:self.totalresults=len(self.data)         
        except:self.totalresults=0         
        if self.data is None or len(self.data)<1 :
           if self.data is None:
              self.data=[]
                                               
           self.data.append(("Error:no result founds",'',1,PLUGIN_PATH+'/skin/micons/error.png','','',9,'',1))  
	   self.totalresults=1 
        if len(self.data)==1 and (self.data[0][0].startswith("Error") or self.data[0][0].startswith("Message")):
           name=self.data[0][0]
           
           param_url=""
           self.data=[]
           self.data.append((name,param_url,1,PLUGIN_PATH+'/skin/micons/error.png','','',9,param_url,1)) 
           self.totalresults=1 
        
            
        
        if self.totalresults>0:       
           self["info"].setText('page   :'+str(self.page)+"/"+str(self.currPage+1)+'\nresults:'+str(self.totalresults))
        else:
           self["info"].setText('page   :'+str(self.page)+"/"+str(self.currPage+1)+'\nresults:'+str(self.totalresults))
           
        self.keyLocked=False
        
        try:self.resultsperpage=self.data[0][8]
	except:self.resultsperpage=45
        self.positionlist = []
        
        posX = -1
        lastindex = 0
        self.Thumbnaillist = []
        self.filelist = []
        self.currPage = -1
        self.dirlistcount = 0
        
        index = 0
        framePos = 0
        Page = 0
        i = 1
        path="/tmp/"
        print "self.dataxx",self.data
        self.filelist=[]
        for x in self.data:
            
            if i > 45:
                break
            if x:
               try:
                self.filelist.append((index,
                 framePos,
                 Page,
                 x[0],
                 x[2]))
                index += 1
                framePos += 1
                if framePos > self.thumbsC - 1:
                    framePos = 0
                    Page += 1
                    
               except:
                  continue     
                    
            else:
                self.dirlistcount += 1

                       
        
        self.maxentry = len(self.filelist) - 1
        self.index =0# lastindex - self.dirlistcount
        
        
        
    def startloaddata(self):
        #return
        self.datalist()
        self.setPicloadConf()
    def setPicloadConf(self):
        sc = getScale()
        self.picload = ePicLoad() 
        self.picload.setPara([self['thumb0'].instance.size().width(),
         self['thumb0'].instance.size().height(),
         sc[0],
         sc[1],
         config.m3uPlayer.cache.value,
         int(config.m3uPlayer.resize.value),
         self.color])
        
        self.initFrame()
        
        self.paintFrame()

    def initFrame(self):
        self.positionlist = []
        for x in range(self.thumbsC):
            frame_pos = self['thumb' + str(x)].getPosition()
            self.positionlist.append((frame_pos[0] - 5, frame_pos[1] - 5))

        frame_pos = self['thumb0'].getPosition()
        self['frame'].setPosition(frame_pos[0] - 5, frame_pos[1] - 5)

    def paintFrame(self):
        if self.maxentry < self.index or self.index < 0:
            return
        pos = self.positionlist[self.filelist[self.index][T_FRAME_POS]]
        self['frame'].moveTo(pos[0], pos[1], 1)
        self['frame'].startMoving()
        if self.currPage != self.filelist[self.index][T_PAGE]:
            self.currPage = self.filelist[self.index][T_PAGE]
            
            self.newPage()
      
        self.updateinfo()
    def newPage(self):
        print "mahmoudxx"
        try:
            self.Thumbnaillist = []
            for x in range(self.thumbsC):
                self['label' + str(x)].setText('')
                self['thumb' + str(x)].hide()
            self["info"].setText('page   :'+str(self.page)+"/"+str(self.currPage+1)+'\nresults:'+str(self.totalresults))
            print "mahmoudxx",self.filelist
            for x in self.filelist:
                
                if x[T_PAGE] == self.currPage:
                    try:title=x[T_NAME][:60]
                    except:title=x[T_NAME]
                    self['label' + str(x[T_FRAME_POS])].setText(str(title))
                    self.Thumbnaillist.append([0, x[T_FRAME_POS], x[T_FULL]])
                    
                    
                    webfile= x[T_FULL]
                    
                    localfile=''
                    wenfile=''
                    webfile= x[T_FULL]
                    print "mahmoudxx2",webfile
                   
                    print "webfile,title",webfile,title
                    
                    if True:
                      try:
                          basename=os.path.split(webfile)[1]
                         
                      except:
                          basename='iconch'
                          
                      localfile='/tmp/m3uPlayer/'+basename
                      
                      title=str(title).strip()
                      
                      if webfile is not None and  webfile.startswith("/usr") and os.path.exists(webfile):
                         localfile=webfile
                         self.downloadback(True,x[T_FRAME_POS],localfile)
                      
                         
                      elif title.startswith('Error') or title.startswith('Message:'):
                          localfile='/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/channels/iconch.png'
                          self.downloadback(True,x[T_FRAME_POS],localfile)
                      elif webfile=='':
                          localfile='/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/skin/channels/iconch.png'
                          self.downloadback(True,x[T_FRAME_POS],localfile)                          
                      else:
                                                
                          self.downloadimage(localfile,webfile,x[T_FRAME_POS])
        except:
            print "error 201"
                      
    def downloadimage(self,localfile,webfile,index):
        
        print "webfile,localfile",webfile,localfile
        if not webfile.startswith("http"):
          
           localfile=PLUGIN_PATH+"/addons/iptv/m3uPlayer/icon.png"
           
           
             
           self.downloadback(True,index,localfile)
        else:   
           client.downloadPage(webfile,localfile).addCallback(self.downloadback,index,localfile).addErrback(self.downloaderror,index)
				
    def downloadback(self,data,index,localfile):
        
        picobject= self['thumb' + str(self.Thumbnaillist[index][1])]
        
        self.showPic(picobject,localfile)
    def downloaderror(self,data,index):
                       
                       localfile=PLUGIN_PATH+"/addons/iptv/m3uPlayer/icon.png"
                       self.downloadback(True,index,localfile)
    def showPic(self,pic=None,picfile=None):
    

	             print 'picfile_lastp',picfile
                     if os.path.exists(picfile)==False:
                        picfile=PLUGIN_PATH+"/addons/iptv/m3uPlayer/icon.png"
                     print 'picfile_last',picfile,os.path.exists(picfile)   
		     try:   
			pic.instance.setPixmap(gPixmapPtr())
			self.scale = AVSwitch().getFramebufferScale()
			self.picload = ePicLoad()
			size = pic.instance.size()
			self.picload.setPara((size.width(), size.height(), self.scale[0], self.scale[1], False, 1, "#FF000000"))
			if enigmaos=='oe2.2':
                            value=self.picload.startDecode(picfile,  False)
			else:
                            value=self.picload.startDecode(picfile, 0, 0, False)
			if value == 0:
				ptr = self.picload.getData()
				
				if ptr != None:
					pic.instance.setPixmap(ptr)
					pic.show()
					del self.picload

		     except:
                         pass
##########
    def search_ch(self):
        from Screens.VirtualKeyBoard import VirtualKeyBoard

        import os
        try:
            txt = config.m3uPlayer.searchstr.value
        except:
            txt = ''

        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title=_('Enter your search term(s)'), text=txt)

    def searchCallback(self, search_txt):
        if search_txt:
            try:
                search_txt = str(search_txt)
                config.m3uPlayer.searchstr.value = search_txt
                config.m3uPlayer.searchstr.save()
                
                self['handlung'].setText('Please wait..')
                try:
                    m3ufile=open("/tmp/m3uPlayer/m3ufile").read()
                    m3ufile="/etc/m3uPlayer/"+m3ufile+".m3u"
                except:
                    m3ufile=''
                
                params = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/addons/iptv/m3uPlayer?url='+m3ufile+'&mode=103&name=search&page=1'
                
                self.newscreen(params)
                return
            except:
                self['handlung'].setText('Error in searching for ' + str(search_txt))                        
######################    
    def updateinfo(self):

       
       title=''           
       param=''
       action=0
     
       self.keyLocked = False
       self['handlung'].setText( " " )
       try:title=str(self.data[self.index][0])
       except:pass           
       try:param=str(self.data[self.index][1]).strip()
       except:pass
       if param is not None and  (param.startswith("http") or param.startswith("rtmp")):
             self.bouquet=True
             self.convert=False
             self.update=False
             self["Key_blue"].setText("+ Bouquet")
             
             self['Key_green'].setText("Search")
             
             
       

           
       else:
           
             
             if "mode=1" in param:
                self.convert=True
                self.bouquet=False
                self.update=True
                self["Key_blue"].setText("M3u2Bouquet")               
                self['Key_green'].setText("Update")

             elif "mode=2" in param:
                self.convert=False
                self.bouquet=False
                self.update=False
                self['Key_blue'].setText(" ")
                self['Key_green'].setText("Search")
                
             else:
                 self.bouquet=False
                 self.convert=False
                 self.update=False
                 self["Key_blue"].setText(" ")
                 self['Key_green'].setText(" ")
             
                
             #self['Key_blue'].hide()       
      
       if self.data is None or len(self.data)<1 :
          self['handlung'].setText("No items available ")
          
          return
       
       if len(self.data)==0 and self.data[0][0].startswith('Error') :
          self['handlung'].setText("Error :check details by info button")
          
          return
       elif len(self.data)==0 and self.data[0][0].startswith('Message:'):    
            self['handlung'].setText(str(self.data[0][0]))
            return
       if self.bqupdate==True:
          title="Bouquets updated successfully"
          
          self['handlung'].setText(title)
          self.closeall()
          return
       self['handlung'].setText(title)
      
       
    def previouspage(self):
        self.bqupdate=False 
        if self.keyLocked==True :
           return
        try:   
           self.preindex=self.index
           self.index -= 9 
           
           if self.index <0:
                   
                   self.index=0
                   self.exit()
                   
                        
              
           
        except:
          self.index=self.preindex-1 
          if self.index <0:
                   
                   self.index=0
                   self.exit()            
        self.paintFrame()   
    def nextpage(self):      
       self.bqupdate=False  
       try: 
        if self.keyLocked==True :
           return
        self.preindex=self.index
        self.index += 9   
        if self.index > self.maxentry:
                   

                   self.index =self.preindex
                   param_url=str(self.data[self.index][7])
                   self.action_params=param_url

                   
                   
                                    
                   self.newscreen(self.action_params) 
                   return
        
                              
               
       except:
          self.index = self.maxentry
       self.paintFrame()      
    def key_left(self):
        self.bqupdate=False 
        if self.keyLocked==True :
           return
        
        self.index -= 1
                
        if self.index < 0 :
              self.index=self.maxentry
              
        self.paintFrame()
        
    def key_right(self):
        self.bqupdate=False 
        if self.keyLocked==True :
           return
        self.preindex=self.index
        self.index += 1
        if self.index > self.maxentry and len(self.data)==45 :
                   

                   self.index =self.preindex
                   param_url=str(self.data[self.index][7])
                   self.action_params=param_url

                   
                   
                                    
                   self.newscreen(self.action_params) 
                   return
                  
                       
        else:
        
          if self.index > self.maxentry:
              self.index = 0
        print "selfindex',maxentery", self.index , self.maxentry      
        self.paintFrame()
       
    def key_up(self):
        self.bqupdate=False 
        if self.keyLocked==True:
           return
        
        self.index -= self.thumbsX
        
        if self.index < 0  :

                   self.index=self.maxentry
                       
        else:
        
          pass  
        
        
        self.paintFrame()
       
    def key_down(self):
        self.bqupdate=False
        if self.keyLocked==True :
           return
        self.preindex=self.index
        self.index += self.thumbsX
        if self.index > self.maxentry and len(self.data)==45:
                   
                   self.index = self.preindex
                   
                  
                  
                      
                   param_url=str(self.data[self.index][7])
                   self.action_params=param_url
                   
                   
                   
                                     
                                   
                   
                                      
                   #self.loaddata()
                   self.newscreen(self.action_params) 
                   
                   return
                       
        else:
        
          if self.index > self.maxentry:
              self.index = 0
        self.paintFrame()
       
        
       
    
    def exit(self):


          i=0
          for screen in self.screens:
              
              if screen==self:
                 del self.screens[i]
                 break
              i=i+1               
          self.close()








    def favexists(self,title=None,param=None):
        if title is None or param is None:
            return False       
        try:

            from xml.etree.ElementTree import ElementTree, dump, SubElement, Element        
            favlocation = "/etc/m3uPlayer"
            xmlfile = favlocation + '/favorites2.xml'            
            tree = ElementTree()
            tree.parse(xmlfile)
            root = tree.getroot()
            i = 0
            for addon in root.iter('addon'):
                    for media in addon.iter('media'):
                        favtitle = str(media.attrib.get('title'))
                        favurl = str(media.text)
                        if title==favtitle and param==favurl:
                            return True
            return False             
        except:
            return False
        

    def delfav(self):
      
       try:
         title=self.data[self.index][0]
         fav_id=self.data[self.index][4]
       except:
         
         self['handlung'].setText('Failed to delete from favorites-1')
         return
                   
       if self.param_title=='GFavorites':
          plugin_id='global'
          section='favorites'
       elif self.param_title=='Gplaylist':
          plugin_id='playlist'
          section='playlist'                  
          
       elif self.param_title=='Favorites':
          plugin_id=self.plugin_id
          section=self.section
       
       elif self.param_title=='SFavorites':
          plugin_id=None
          section=self.section            
       from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import delfavorite
        
       
       result=delfavorite(title,None)
       if result==True:
           
           

           
                
           from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import getfav_datalist
           self.source_data=getfav_datalist(self.plugin_id,'iptv')
           
           self.loaddata()
           self['handlung'].setText('Item deleted successfully from favorites')                    

       
           
       else:
           self['handlung'].setText('Failed to delete from favorites') 
       #
    def savetofavorites2(self):
         
           
           self.bqupdate=False 
           if self.favmode==True:
              self.delfav()
              return
           from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfavorites import addfavorite
           
           import sys
           result=False

           
           try:
              param=str(self.data[self.index][1])
              
             
              
              title=str(self.data[self.index][0])
              
              if self.favexists(title,param):
                 self['handlung'].setText('Channel already added to favorites.')
               
                 return              
              
              result=addfavorite(self.plugin_id,title,param,self.section)
             
           except:
               result=False
              
           if result==True:
               self['handlung'].setText('Item added successfully to favorites.')
           else:
               self['handlung'].setText('Failed to add to favorites.')




              
             
          
            
    def savetofavorites(self):
          
           
           self.bqupdate=False  
           if self.favmode==True :
               self.delfav()
               return    
           self.savetofavorites2()    
###########################################################end process paramaeters         
#######################    
  

    def ok_clicked(self):         
              try:itemindex=self.index
              except:return
            
              try:title=str(self.data[self.index][0])                
              except:return                   
               
               
              try:param=str(self.data[self.index][1])
              except:return
              
                                             
              
              
              self.keyLocked=False
             
              self.playlist=[]
   
              
            
                    
                                    
              self.playlist=self.createplaylist()
              
              self.preindex=self.index 
                               
               
              if title.strip().startswith("Error") or title.strip().startswith("Message"):
                    self.keyLocked=False
                    
                    self.exit()
                    return              
                            
              if True:
                 self.action_params=param
                
                 
                 
                 

                 self.newscreen(self.action_params)                                   
                 
             
                 

    def createplaylist(self):
      try:
        playlist=[]
        self.favplaylist=[]

                 
        for item in self.data:

            try:title=str(item[0])
            except:continue
            try:param=str(item[1])
            except:continue
            self.favplaylist.append((title,param))
            if not param.startswith("http"):
               continue
            playlist.append((title,param))
            
        return playlist        
      except:
        return []    
    def getmu3info(self,m3ufile):
        import re
        list1=[]
        if m3ufile.find('m3u') > -1:
            done = True
            try:
                myfile = open(m3ufile, 'r').read()
                regex = re.findall('#EXTINF.*,(.*\\s)\\s*(.*)', myfile)
                if not len(regex) > 0:
                    regex = re.findall('((.*.+)(.*))', myfile)
                ts = ''
                chan_counter = 0
                video_list_temp = []
                for text in regex:
                    title = text[0].strip()
                    url = text[1].strip()
                    chan_counter += 1
                    if 'rtmp' in url:
                        url = fixlink(url)
                    #addDir(title, url, 0, '')
                    list1.append((title,url))

            except:
                return []
           
        return list1


    def m3u2bouquet(self,result):
          if not result:
              return
          if self.convert==False:
             
             return               
          title=str(self.data[self.index][0])
          m3ufile = "/etc/m3uPlayer/"+str(self.data[self.index][0])+".m3u"
          list1=self.getmu3info(m3ufile)                          
          
         
          
          from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import addstream   
          for item in list1:

              try:
                
                
                try:
                    channelname = str(item[0])
                except:
                    continue

                try:
                   url = str(item[1])
                except:
                   continue
                if url is not None and not url.startswith("http") and not url.startswith("rtmp"):
                   
                   continue
                
                error=addstream(url,channelname,title) 
                continue
              except:
                   continue
          if list1:                                 
               self['handlung'].setText('Stream added to '+'m3uPlayer '+ 'bouquet\please wait loading bouquets''')
               eDVBDB.getInstance().reloadServicelist()
               eDVBDB.getInstance().reloadBouquets()
               self['handlung'].setText('m3u converted successfully to enigma bouquet '+title)
               return                     
  
    def exportchannels(self):

              
             
          if self.convert==True:
              self.session.openWithCallback(self.m3u2bouquet, MessageBox, _('m3u links will be converted to enigma bouquet,Convert now?'), MessageBox.TYPE_YESNO)
              
              return
          itemtitle=str(self.data[self.index][0])
          
          
          if self.bouquet==False:
             
             return
          try:
            
            
	    try:channelname = str(self.data[self.index][0])
	    except:self['handlung'].setText("Failed to export to bouquet[erro:601]")

	    try:
               url = str(self.data[self.index][1])
            except:
               self['handlung'].setText("Failed to export to bouquet[erro:602]")
               return 
            if url is not None and not url.startswith("http") and not url.startswith("rtmp"):
               
               return
            from Plugins.Extensions.m3uPlayer.lib.m3uPlayerfunctions import addstream   
            try:item_title=open("/tmp/m3uPlayer/m3ufile").read()
            except:item_title="m3uPlayer"
            error=addstream(url,channelname,item_title) 
            if error=='none':
               self['handlung'].setText('Stream added to '+item_title+ ' bouquet\please wait loading bouquets''')
               eDVBDB.getInstance().reloadServicelist()
               eDVBDB.getInstance().reloadBouquets()
               self['handlung'].setText('Stream added successfully to '+item_title)
               return               
            else:
               self['handlung'].setText(error)
          except:
               self['handlung'].setText('Failed to add to bouquets[erro:604]')                                 
    

        
    def newscreen(self,params=None):
       try:self.timer.stop()
       except:pass    
       self['handlung'].setText("Please wait.. ")
       self.loadscreen(params)        


        
    def loadscreen(self,params=None):
       try:title=str(self.data[self.index][0])
       except:title=self.group_title
       if params is None:
          param=self.data[self.index][1]
       else:
          param=params 
       
       
       self.lock=True
       self.keyLocked=True
       
   
       
       self.preindex=self.index
       if 'mode=' in param:
          
          
          if 'mode=9' in param:
              self.close()
              return
          exec 'from Plugins.Extensions.m3uPlayer.addons.iptv.m3uPlayer.default import process_mode'
          self.source_data=process_mode([],param)
       
          try:name=self.source_data[0][0]
          except: name=None
         
          if name is not None and  name.startswith("Error"):
             self['handlung'].setText('Error:,check /tmp/m3uPlayer_log for more details 1')
             self.lock=False
             self.keyLocked=False
             
             return
          elif name is not None  and name.startswith("Message"):
               self['handlung'].setText(str(name))

               self.lock=False
               self.keyLocked=False               
               return
          elif name is None:
              self['handlung'].setText('Error:,no data,check /tmp/m3uPlayer_log for more details 1')
              self.lock=False
              self.keyLocked=False               
              return
              
            
          player=False
          
          self.index=0
       else:
          self.source_data=self.data
          player=True

      
       print "xxx",self.index,len(self.source_data)
       if self.source_data is not None:
           if len(self.source_data)>0:
               name=self.source_data[self.index][0]
               
               
               param=self.source_data[self.index][1]
               
              
               if not 'Error:' in name and not 'Error:' in param and not "Message:" in param and not "Message:" in param:
                   
                  if param.startswith("http") and player==True:
                      
                     
                                      
                     
                      from Plugins.Extensions.m3uPlayer.lib.TSplayer import TSplayer
                      self.session.openWithCallback(self.updateindex,TSplayer, serviceRef=None,serviceUrl=str(param),serviceName=name,serviceIcon='', playlist = self.playlist, playindex =self.index,bqindex=self.bqindex,favmode=self.favmode)    			
	              self['handlung'].setText(name)                   

                  
                  else:
                     
                      self.info['name']=name
                     
                      self.session.openWithCallback(self.updateinfo,m3uPlayerScreen11_p,info=self.info,action_params=param,source_data=self.source_data,nextrun=self.nextrun+1,screens=self.screens,bqindex=self.preindex)
               else:
                  if 'Message:' in param:
                     self['handlung'].setText( str(param))
                  else:   
                     self['handlung'].setText('Error:,check /tmp/m3uplayer_log for more details 1')      
           else:
                  self['handlung'].setText('No data returned,check /tmp/m3uplayer_log for more details 2')
       else:
                  self['handlung'].setText('No data returned,check /tmp/m3uplayer_log for more details 3')

       self.index=self.preindex 

    def updateindex(self,playindex=0):
        if self.favmode==True :
            return
            
        elif not playindex==self.index:
             self.index=playindex
             self.paintFrame() 
    def updateinfo2(self):

        pass
                  
    def closeall(self):
          if self.spinner_running==True:
          
            self.stopSpinner()   
                     
          try:self.stopSpinner()
          except:pass
          for screen in self.screens:
                try:screen.close()
                except:continue
          self.screens=[]
def removeFiles(folder_path):
   try:
      import os
      for file_object in os.listdir(folder_path):
          file_object_path = os.path.join(folder_path, file_object)
          if os.path.isfile(file_object_path):
              os.remove(file_object_path)
          
   except:
          pass

  

 
