# uncompyle6 version 2.11.2
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.12 (v2.7.12:d33e0cf91556, Jun 27 2016, 15:19:22) [MSC v.1500 32 bit (Intel)]
# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/lib/TSmediaSetup.py
# Compiled at: 2017-08-16 22:00:00

from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, configfile,config
from Screens.Screen import Screen
from Components.ActionMap import ActionMap, NumberActionMap
from Plugins.Extensions.m3uPlayer.lib.imports import *
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, configfile

class  m3uPlayerSetup(Screen, ConfigListScreen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = 'm3uPlayerSetup2'
        self.list = []
        
       
        self.list.append(getConfigListEntry(_('Show plugin in main menu(need e2 restart):'), config.m3uPlayer.menuplugin))
        
        try:
           
           
            self.list.append(getConfigListEntry(_('Auto update for software:'), config.m3uPlayer.softaware_update))
            
        except:
            pass

        ConfigListScreen.__init__(self, self.list, session)
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.ok,
         'green': self.keySave,
         'green': self.keySave,
         'cancel': self.keyClose}, -2)

    def refresh(self):
        self.list = []
        

    def ok(self):
        return


    def keySave(self):
        for x in self['config'].list:
            x[1].save()

        configfile.save()
        self.close()

   
    def keyClose(self):
        for x in self['config'].list:
            x[1].cancel()

        self.close(False)
