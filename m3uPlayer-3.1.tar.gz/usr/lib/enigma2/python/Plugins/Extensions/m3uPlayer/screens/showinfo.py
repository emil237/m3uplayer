# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/screens/showinfo.py
from Plugins.Extensions.m3uPlayer.lib.gimports import *
from Components.ScrollLabel import ScrollLabel

def getskintype():
    skin_type = ''
    skin_type_file = '/usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/interface/skin'
    if os.path.exists(skin_type_file):
        lines = open(skin_type_file, 'r').readlines()
        for txt in lines:
            txt = txt.strip().replace(' ', '')
            if 'skin==' in txt:
                skin_type = txt.split('==')[1]

    return skin_type


def getCmdOutput(cmd):
    import os
    pipe = os.popen('{ ' + cmd + '; } 2>&1', 'r')
    text = pipe.read()
    pipe.close()
    if text[-1:] == '\n':
        text = text[:-1]
    return text


def getextra_data():
    data = ''
    now = ''
    image_version = ''
    m3uPlayer_version = ''
    currkernel = ''
    skinres = ''
    model = ''
    if True:
        import time
        now = time.strftime('%c')
        model = getCmdOutput('cat /proc/stb/info/model')
        from Components.About import about
        try:
            image_version = about.getImageVersionString()
        except:
            image_version = ''

        m3uPlayer_version = currversion
        skinres = getskintype()
    data = data + 'date:' + str(now) + '\nmodel:' + str(model) + '\nimage_version:' + str(image_version) + '\nm3uPlayer_version:' + str(m3uPlayer_version) + '\nSkin_resolution:' + str(skinres)
    return data


class m3uPlayerinfo(Screen):

    def __init__(self, session, plugin_id = None, sender = None, data = '', cmd = None):
        Screen.__init__(self, session)
        self.skinName = 'm3uPlayerinfoScreen'
        title = 'Information'
        self.sender = sender
        if data is None:
            data = ''
        self.data = data
        self.cmd = cmd
        self.finishedCallback = None
        self.closeOnSuccess = False
        cmdlist = None
        self.plugin_id = plugin_id
        self.longlog = False
        self['text'] = ScrollLabel('')
        self['actions'] = ActionMap(['WizardActions', 'DirectionActions', 'ColorActions'], {'ok': self.cancel,
         'back': self.cancel,
         'green': self.standardlog,
         'yellow': self.datalog,
         'blue': self.executelog,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown}, -1)
        self.cmdlist = cmdlist
        self.newtitle = title
        self.onShown.append(self.updateTitle)
        self.onLayoutFinish.append(self.standardlog)
        return

    def updateTitle(self):
        self.setTitle(self.newtitle)

    def executelog(self):
        text = ''
        import os, sys
        if self.cmd is None:
            try:
                afile = sys.argv[0]
                cmd = 'python ' + afile + ' 1 ' + "'" + sys.argv[2] + "'"
            except:
                try:
                    afile = sys.argv[0]
                    cmd = 'python ' + afile + ' 1 ' + "'" + '' + "'"
                except:
                    return

        else:
            cmd = self.cmd
        from Plugins.Extensions.m3uPlayer.lib.libinstaller.Console2 import m3uPlayerConsole2
        self.session.open(m3uPlayerConsole2, title='Console', cmdlist=[str(cmd)], finishedCallback=None, closeOnSuccess=False, instr='Executing ' + str(cmd), endstr='')
        return

    def datalog(self):
        self['text'].setText('  ')
        data = ''
        if True:
            import os
            data = data + '\n' + '************addon data log-data.txt**********************\n'
            if os.path.exists('/tmp/m3uPlayer/data.txt'):
                f = open('/tmp/m3uPlayer/data.txt', 'r')
                lines = f.readlines()
                data = data + '\n**********************************\n'
                for line in lines:
                    data = data + line

            data = data + '\n************End addon data log**********************\n'
            self['text'].setText(data)

    def standardlog(self):
        self['text'].setText('  ')
        data = ''
        if not self.data == '':
            self['text'].setText(self.data)
            return
        elif True:
            import os
            data = '************Press GREEN for standard log,YELLOW for data log,BLUE to excute last command in console**********************\n'
            data = data + '\n' + '************Errors and logs-m3uPlayer_log**********************\n'
            if os.path.exists('/tmp/m3uPlayer_log'):
                f = open('/tmp/m3uPlayer_log', 'r')
                lines = f.readlines()
                data = data + '\n**********************************\n'
                for line in lines:
                    data = data + line

            if os.path.exists('/tmp/m3uPlayer_log2'):
                data = data + '\n' + '************Errors and logs-m3uPlayer_log2**********************\n'
                lines = open('/tmp/m3uPlayer_log2').readlines()
                for line in lines:
                    data = data + str(line)

            data = data + '\n************End Errors and logs**********************\n'
            if self.plugin_id is not None and '/' in self.plugin_id:
                try:
                    path = PLUGIN_PATH + '/addons/' + self.plugin_id + '/error_log'
                    afile = open(path, 'a')
                    afile.write('\n***********************************' + data + '\n****************************************************')
                    afile.close()
                except:
                    pass

            self['text'].setText(data)
            return
        else:
            return
            return

    def cancel(self):
        self.close()