# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/player/__init__.py
pass