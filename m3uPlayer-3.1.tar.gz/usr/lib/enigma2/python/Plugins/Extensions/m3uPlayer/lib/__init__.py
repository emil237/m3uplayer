# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/lib/__init__.py
pass