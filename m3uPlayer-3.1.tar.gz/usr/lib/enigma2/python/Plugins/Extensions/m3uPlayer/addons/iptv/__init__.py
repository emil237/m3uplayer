# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/BrothersTV/addons/iptv/__init__.py
pass