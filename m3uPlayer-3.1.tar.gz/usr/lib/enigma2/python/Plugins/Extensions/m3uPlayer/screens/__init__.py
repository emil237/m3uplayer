# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/screens/__init__.py
pass