# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/screens/addon.py
from Plugins.Extensions.m3uPlayer.lib.gimports import *
from Plugins.Extensions.m3uPlayer.lib.pltools import deldata, dellog, logdata, logtmpdata, downloadxmlpage, trace_error, restore_settingsfile, backup_settingsfile, getimages_cahepath
import xml.etree.cElementTree
appPath = PLUGIN_PATH
updated_addons_file = appPath + '/updates/updated_addons'
updatesServer = 'http://tunisia-dreambox.info/m3uPlayer'

class Addon:

    def __init__(self, sParams):
        self.addon_id = sParams.get('addon_id', '')
        self.section_id = sParams.get('section_id', '')
        print 'sParams-addon', sParams
        if self.addon_id:
            self.addon_path = appPath + '/addons/' + self.section_id + '/' + self.addon_id
            self.addonxml_path = self.addon_path + '/addon.xml'
            self.params_path = self.addon_path + '/params'
            self.settingsPath = self.addon_path + '/resources/settings.xml'
            self.sParams = self.getsParams()
        else:
            self.sParams = sParams

    def getsParams(self):
        if not os.path.exists(self.params_path):
            return {}
        lines = open(self.params_path).readlines()
        tParams = {}
        for line in lines:
            line = line.strip()
            if line == '':
                continue
            try:
                key, value = line.split('==')
            except:
                continue
            else:
                if key == 'plugin_id':
                    key = 'addon_id'
                if key == 'section':
                    key = 'section_id'
                tParams[key] = value

        return tParams

    def getAddonInfo(self):
        addParams = {}
        if not os.path.exists(self.addonxml_path):
            return addParams
        else:
            try:
                tree = xml.etree.cElementTree.parse(self.addonxml_path)
                root = tree.getroot()
                addParams['addon_id'] = str(root.get('id'))
                addParams['version'] = str(root.get('version'))
                addParams['provider'] = str(root.get('provider-name'))
                addParams['name'] = str(root.get('name'))
                addParams['description'] = str(root.get('description'))
            except:
                trace_error
                return {}

            return addParams

    def getadupdatesInfo(self):
        if not os.path.exists(updated_addons_file):
            return (False, 'No updates available')
        updated_addons = []
        addParams = self.getAddonInfo()
        cversion = addParams.get('version', '1.0.0')
        uadddons = open(updated_addons_file).read()
        if ',' in uadddons:
            updated_addons = uadddons.split(',')
        else:
            updated_addons.append(txt)
        addon_update = False
        for updated_addon in updated_addons:
            if self.addon_id in updated_addon:
                if not self.addon_id == updated_addon.split('_')[1]:
                    addon_update = False
                    continue
                uversion = updated_addon.split('_')[-1]
                serverAddonName = updated_addon
                try:
                    if float(uversion.replace('.', '')) > float(cversion.replace('.', '')):
                        addon_update = True
                    else:
                        addon_update = False
                except:
                    trace_error()
                    addon_update = False

        updatesInfo = {}
        serverAddon_file = updatesServer + '/' + self.section_id + '/' + serverAddonName + '.zip'
        updatesInfo.update({'cversion': cversion,
         'uversion': uversion,
         'uaddon_name': serverAddonName,
         'serverAddon_file': serverAddon_file})
        return (addon_update, updatesInfo)

    def getSetting(self, id):
        item = id
        settParams = {}
        if not os.path.exists(self.settingsPath):
            return {}
        else:
            tree = xml.etree.cElementTree.parse(self.addonxml_path)
            root = tree.getroot()
            try:
                for setting in root.iter('setting'):
                    type = setting.get('type')
                    if type == 'bool':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'action':
                        idx = setting.get('label')
                        action = setting.get('action')
                        if idx == item:
                            xtxt = action
                            return xtxt
                    elif type == 'text':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'enum':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            ix = default
                            return ix
                    elif type == 'folder':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'labelenum':
                        idx = setting.get('id')
                        values = setting.get('values')
                        if idx == item:
                            vals = values.split('|')
                            n = len(vals) - 1
                            xtxt = vals[n]
                            return xtxt
                    elif type == 'number':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'select':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt

            except:
                for setting in root.getiterator('setting'):
                    type = setting.get('type')
                    if type == 'bool':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'action':
                        idx = setting.get('label')
                        action = setting.get('action')
                        if idx == item:
                            xtxt = action
                            return xtxt
                    elif type == 'text':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'enum':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            ix = default
                            return ix
                    elif type == 'folder':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'labelenum':
                        idx = setting.get('id')
                        values = setting.get('values')
                        if idx == item:
                            vals = values.split('|')
                            n = len(vals) - 1
                            xtxt = vals[n]
                            return xtxt
                    elif type == 'number':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt
                    elif type == 'select':
                        idx = setting.get('id')
                        default = setting.get('default')
                        if idx == item:
                            xtxt = default
                            return xtxt

            return

    def getSetting2(self, settingID = None, default = '', getLabel = False):
        if settingID is None and getLabel == True:
            return ('', default)
        elif settingID is None and getLabel == False:
            return default
        else:
            xfile = self.settingsPath
            if not os.path.exists(xfile):
                if getLabel == True:
                    return ('', default)
                else:
                    return default
            xmlText = open(xfile).read()
            if '&' in xmlText:
                xmlText = xmlText.replace('&', 'AxNxD')
                f2 = open(plugin_path + '/tmp/temp.xml', 'w')
                f2.write(xmlText)
                f2.close()
                cmd = "mv '/tmp/temp.xml' " + xfile
                os.system(cmd)
            try:
                tree = xml.etree.cElementTree.parse(xfile)
                root = tree.getroot()
            except Exception as error:
                printE()
                print 'error', str(error)
                return ('', '')

            i = 0
            for setting in root.iter('setting'):
                sid = setting.attrib.get('id', '')
                if sid == settingID:
                    value = setting.attrib.get('default', default)
                    if value == 'false' or value == 'False':
                        value = False
                    elif value == 'true' or value == 'True':
                        value = True
                    if getLabel == True:
                        return (setting.attrib.get('label', ''), value)
                    else:
                        return value

            if getLabel == True:
                return ('', default)
            return default
            return

    def setSetting(self, setting_id, value):
        """Sets a script setting."""
        if not os.path.exists(self.settingsPath):
            return {}
        elif value is None:
            return False
        elif self.settingsPath is None:
            return False
        else:
            tree = xml.etree.cElementTree.parse(self.settingsPath)
            root = tree.getroot()
            for setting in root.iter('setting'):
                id = setting.get('id')
                if setting_id == id:
                    try:
                        setting.set('default', value)
                        tree.write(self.settingsPath)
                        return True
                    except:
                        return False

            return False
            return