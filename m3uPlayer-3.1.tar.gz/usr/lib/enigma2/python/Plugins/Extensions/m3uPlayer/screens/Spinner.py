# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/m3uPlayer/screens/Spinner.py
from Components.GUIComponent import GUIComponent
from Plugins.Extensions.m3uPlayer.lib.gimports import *
from enigma import ePixmap

class Spinner(GUIComponent):

    def __init__(self, Bilder):
        GUIComponent.__init__(self)

    def SetBilder(self, Bilder):
        self.Bilder = Bilder

    GUI_WIDGET = ePixmap

    def start(self, Bilder):
        self.len = 0
        self.SetBilder(Bilder)
        self.timer = eTimer()
        try:
            if enigmaos == 'oe2.0':
                self.timer.callback.append(self.Invalidate)
            else:
                return
                self.timer_conn = self.timer.timeout.connect(self.Invalidate)
        except:
            pass

        self.timer.start(100)

    def stop(self):
        self.timer.stop()
        if enigmaos == 'oe2.0':
            self.timer.callback.remove(self.Invalidate)
        else:
            self.timer_conn = None
        return

    def destroy(self):
        try:
            self.timer.stop()
            if enigmaos == 'oe2.0':
                self.timer.callback.remove(self.Invalidate)
            else:
                self.timer_conn = None
        except:
            pass

        return

    def Invalidate(self):
        try:
            if self.instance:
                if self.len >= len(self.Bilder):
                    self.len = 0
                self.instance.setPixmapFromFile(self.Bilder[self.len])
                self.len += 1
        except:
            pass